@echo off
TITLE ESS-AI Space Reliability Platform — Backend Server
COLOR 0B

echo.
echo  ============================================================
echo   ESS-AI SPACE RELIABILITY INTELLIGENCE PLATFORM v2.4.1
echo   AI-Driven Anomaly Detection for Component Burn-In
echo  ============================================================
echo.

cd /d "%~dp0"

echo [1/3] Checking Python environment...
python --version 2>nul || (echo ERROR: Python not found. Install Python 3.10+ && pause && exit /b 1)

echo [2/3] Installing dependencies (first run only)...
pip install -r requirements.txt --quiet

echo [3/3] Starting FastAPI backend server...
echo.
echo   API Documentation: http://localhost:8000/docs
echo   ReDoc:             http://localhost:8000/redoc
echo   WebSocket Feed:    ws://localhost:8000/ws/live
echo   Frontend:          Open frontend/index.html in browser
echo.
echo  Press Ctrl+C to stop the server
echo  ============================================================
echo.

python main.py

pause
