# ============================================================
#  ESS-AI BACKEND — schemas.py
#  Pydantic Request/Response Schemas
# ============================================================
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime


# ─── LOT SCHEMAS ───
class LotCreate(BaseModel):
    lot_id: str = Field(..., min_length=3, max_length=20, example="LOT-A77")
    description: Optional[str] = None
    device_type: Optional[str] = None
    technology_node: Optional[str] = "28nm CMOS"
    burn_in_temp: float = 125.0
    burn_in_duration: float = 168.0


class LotResponse(BaseModel):
    id: int
    lot_id: str
    description: Optional[str]
    device_type: Optional[str]
    technology_node: Optional[str]
    burn_in_temp: float
    burn_in_duration: float
    created_at: datetime
    status: str
    component_count: int = 0
    anomaly_count: int = 0
    pass_rate: float = 0.0

    class Config:
        from_attributes = True


# ─── COMPONENT SCHEMAS ───
class ComponentCreate(BaseModel):
    component_id: str
    lot_id: str
    parameter: str
    unit: str = "µA"
    value_0h: float
    value_24h: Optional[float] = None
    value_96h: Optional[float] = None
    value_168h: Optional[float] = None
    abs_limit_max: Optional[float] = None
    abs_limit_min: Optional[float] = None


class ComponentResponse(BaseModel):
    id: int
    component_id: str
    lot_id: str
    parameter: str
    unit: str
    value_0h: float
    value_24h: Optional[float]
    value_96h: Optional[float]
    value_168h: Optional[float]
    lot_mean: Optional[float]
    lot_sigma: Optional[float]
    z_score: Optional[float]
    abs_limit_max: Optional[float]
    module_a_flag: bool
    module_b_flag: bool
    is_hard_fail: bool
    is_latent_defect: bool
    anomaly_score: Optional[float]
    drift_rate: Optional[float]
    pred_value_168h: Optional[float]
    confidence: Optional[float]
    final_decision: str
    created_at: datetime

    class Config:
        from_attributes = True


# ─── ANALYSIS REQUEST SCHEMAS ───
class OutlierAnalysisRequest(BaseModel):
    lot_id: str = "ALL"
    parameter: str = "IDDQ"
    time_point: str = Field("value_168h", description="Which time-point value to analyze")
    z_threshold: float = Field(3.0, ge=1.0, le=6.0)
    iqr_multiplier: float = Field(1.5, ge=0.5, le=4.0)
    method: str = Field("ensemble", description="zscore | iqr | isoforest | lof | ensemble")
    contamination: float = Field(0.05, ge=0.01, le=0.5)


class DriftAnalysisRequest(BaseModel):
    lot_id: str = "ALL"
    parameter: str = "IDDQ"
    slope_multiplier: float = Field(0.003, ge=0.0005, le=0.02)
    model_type: str = Field("ensemble", description="poly | ridge | gbr | ensemble")
    degree: int = Field(3, ge=1, le=5)


class FullAnalysisRequest(BaseModel):
    lot_id: str = "ALL"
    parameter: str = "ALL"
    z_threshold: float = 3.0
    iqr_multiplier: float = 1.5
    slope_multiplier: float = 0.003
    method: str = "ensemble"
    model_type: str = "ensemble"


# ─── ANALYSIS RESULT SCHEMAS ───
class ComponentResult(BaseModel):
    component_id: str
    lot_id: str
    parameter: str
    value_0h: float
    value_24h: Optional[float]
    value_96h: Optional[float]
    value_168h: Optional[float]
    lot_mean: float
    lot_sigma: float
    z_score: float
    z_flag: bool
    iqr_flag: bool
    isoforest_flag: bool
    lof_flag: bool
    ensemble_flag: bool
    pred_value_168h: Optional[float]
    drift_rate: Optional[float]
    safety_slope: Optional[float]
    drift_flag: bool
    anomaly_score: float
    final_decision: str
    confidence: float


class OutlierAnalysisResult(BaseModel):
    run_id: str
    lot_id: str
    parameter: str
    method: str
    z_threshold: float
    total: int
    flagged: int
    passed: int
    latent_defects_caught: int
    flag_rate: float
    lot_mean: float
    lot_sigma: float
    iqr_upper_fence: float
    iqr_lower_fence: float
    precision: Optional[float]
    recall: Optional[float]
    f1_score: Optional[float]
    components: List[ComponentResult]


class DriftAnalysisResult(BaseModel):
    run_id: str
    lot_id: str
    parameter: str
    model_type: str
    mae: float
    rmse: float
    r_squared: float
    drift_flags: int
    safety_slope_limit: float
    lot_mean: float
    components: List[ComponentResult]


class FullAnalysisResult(BaseModel):
    run_id: str
    outlier: OutlierAnalysisResult
    drift: DriftAnalysisResult
    combined_flags: int
    total_components: int
    pass_count: int
    reject_count: int
    latent_defects: int
    pass_rate: float
    summary: Dict[str, Any]


# ─── SHAP / XAI SCHEMAS ───
class SHAPResult(BaseModel):
    component_id: str
    lot_id: str
    parameter: str
    final_decision: str
    base_value: float
    shap_values: Dict[str, float]
    feature_values: Dict[str, float]
    top_feature: str
    top_shap: float
    decision_reason: str
    anomaly_score: float
    confidence: float


# ─── REPORT SCHEMAS ───
class LotReportSummary(BaseModel):
    lot_id: str
    total_components: int
    pass_count: int
    reject_count: int
    latent_defects: int
    drift_flags: int
    pass_rate: float
    max_z_score: float
    lot_mean_v0: float
    lot_sigma_v0: float
    highest_anomaly_score: float
    screening_complete: bool


class MasterReport(BaseModel):
    report_id: str
    generated_at: str
    total_lots: int
    total_components: int
    total_passed: int
    total_rejected: int
    total_latent_caught: int
    overall_pass_rate: float
    module_a_precision: float
    module_a_recall: float
    module_b_mae: float
    module_b_r2: float
    lot_summaries: List[LotReportSummary]


# ─── SPACECRAFT TEST SCHEMAS ───
class SpacecraftTestResponse(BaseModel):
    test_code: str
    test_name: str
    category: str
    unit: str
    typical_value: Optional[float]
    abs_max_limit: Optional[float]
    abs_min_limit: Optional[float]
    standard: Optional[str]
    description: Optional[str]

    class Config:
        from_attributes = True


# ─── SIMULATE REQUEST ───
class SimulateRequest(BaseModel):
    n_lots: int = Field(6, ge=1, le=20)
    components_per_lot_param: int = Field(40, ge=5, le=500)
    latent_defect_rate: float = Field(0.04, ge=0.0, le=0.3)
    hard_fail_rate: float = Field(0.02, ge=0.0, le=0.2)
    parameters: List[str] = ["IDDQ", "ILEAK", "TPROP", "VTH_N", "VTH_P", "ICC", "VOUT", "CMRR", "PSRR", "TID"]
