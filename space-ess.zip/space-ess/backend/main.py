# ============================================================
#  ESS-AI BACKEND — main.py
#  FastAPI Application Entry Point
# ============================================================
import asyncio
import json
import uuid
from contextlib import asynccontextmanager
from datetime import datetime
from typing import List

import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

from database import engine, SessionLocal
import models
from api.routes import router
from ml.data_gen import generate_dataset, compute_lot_stats, get_test_catalog, SPACECRAFT_TESTS


# ─── LIFESPAN: DB INIT + SEED ───
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Create tables and seed spacecraft test catalog on startup."""
    models.Base.metadata.create_all(bind=engine)

    db = SessionLocal()
    try:
        # Seed spacecraft test catalog
        if db.query(models.SpacecraftTest).count() == 0:
            for test in get_test_catalog():
                db.add(models.SpacecraftTest(
                    test_code=test["test_code"],
                    test_name=test["test_name"],
                    category=test["category"],
                    unit=test["unit"],
                    typical_value=test["typical_value"],
                    abs_max_limit=test["abs_max_limit"],
                    abs_min_limit=test["abs_min_limit"],
                    safety_slope_multiplier=test["safety_slope_multiplier"],
                    standard=test["standard"],
                    description=test["description"],
                ))
            db.commit()
            print(f"[ESS-AI] Seeded {len(SPACECRAFT_TESTS)} spacecraft test parameters")

        # Auto-generate demo dataset if empty
        if db.query(models.Component).count() == 0:
            print("[ESS-AI] Generating initial demo dataset...")
            df = generate_dataset(n_lots=6, components_per_lot_param=30,
                                  latent_defect_rate=0.04, hard_fail_rate=0.02,
                                  parameters=list(SPACECRAFT_TESTS.keys())[:8])
            df = compute_lot_stats(df)

            for _, row in df.iterrows():
                if not db.query(models.Lot).filter(models.Lot.lot_id == row["lot_id"]).first():
                    db.add(models.Lot(
                        lot_id=row["lot_id"],
                        description=f"Demo Lot — {row['lot_id']}",
                        device_type="ASIC-SpaceSoC",
                        technology_node="28nm CMOS",
                        burn_in_temp=125.0,
                        burn_in_duration=168.0,
                    ))
                    db.flush()

                db.add(models.Component(
                    component_id=row["component_id"],
                    lot_id=row["lot_id"],
                    parameter=row["parameter"],
                    unit=row.get("unit", "µA"),
                    value_0h=float(row["value_0h"]),
                    value_24h=float(row["value_24h"]),
                    value_96h=float(row["value_96h"]),
                    value_168h=float(row["value_168h"]),
                    lot_mean=float(row.get("lot_mean", row["value_0h"])),
                    lot_sigma=float(row.get("lot_sigma", 1.0)),
                    z_score=float(row.get("z_score", 0)),
                    abs_limit_max=float(row.get("abs_limit_max", 9999)),
                    abs_limit_min=float(row.get("abs_limit_min", -9999)),
                ))

            db.commit()
            print(f"[ESS-AI] Demo dataset loaded: {len(df)} components")

    finally:
        db.close()

    yield
    print("[ESS-AI] Shutting down...")


# ─── APP FACTORY ───
app = FastAPI(
    title="ESS-AI Space Reliability Intelligence Platform",
    description=(
        "AI-Driven Anomaly Detection for Electronic Component Burn-In & Screening. "
        "Module A: Dynamic Outlier Detection | Module B: Time-Series Drift Prediction | "
        "XAI Explainability Engine"
    ),
    version="2.4.1",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# ─── CORS ───
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],       # In production: restrict to frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── API ROUTES ───
app.include_router(router)

# ─── SERVE FRONTEND STATIC FILES ───
FRONTEND_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "frontend")
if os.path.isdir(FRONTEND_DIR):
    app.mount("/app", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")

    @app.get("/")
    def root():
        return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))


# ─── WEBSOCKET: LIVE SCREENING FEED ───
class ConnectionManager:
    def __init__(self):
        self.active: List[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.active.append(ws)

    def disconnect(self, ws: WebSocket):
        self.active.remove(ws)

    async def broadcast(self, data: dict):
        msg = json.dumps(data)
        disconnected = []
        for ws in self.active:
            try:
                await ws.send_text(msg)
            except Exception:
                disconnected.append(ws)
        for ws in disconnected:
            self.active.remove(ws)


manager = ConnectionManager()


@app.websocket("/ws/live")
async def websocket_live(ws: WebSocket):
    """WebSocket endpoint streaming live screening events."""
    await manager.connect(ws)
    try:
        # Send a stream of simulated screening events
        import random
        parameters = list(SPACECRAFT_TESTS.keys())
        lot_ids = ["LOT-A77", "LOT-B12", "LOT-C34", "LOT-D91", "LOT-E55", "LOT-F03"]
        decisions = ["PASS"] * 18 + ["REJECT"] + ["MARGINAL"]

        counter = 0
        while True:
            await asyncio.sleep(1.5)
            param = random.choice(parameters)
            spec = SPACECRAFT_TESTS[param]
            lot = random.choice(lot_ids)
            decision = random.choice(decisions)
            z = round(random.gauss(0, 1) if decision == "PASS" else random.gauss(3.8, 0.5), 3)
            v0 = round(spec["typical"] + z * spec["sigma"], 4)

            event = {
                "type": "screening_event",
                "timestamp": datetime.utcnow().isoformat(),
                "component_id": f"{lot}-{param}-{counter:05d}",
                "lot_id": lot,
                "parameter": param,
                "value_0h": v0,
                "z_score": z,
                "decision": decision,
                "anomaly_score": round(min(100, abs(z) / 3 * 60 + random.randint(0, 30)), 1),
                "module": "A" if decision == "REJECT" and random.random() > 0.5 else ("B" if decision == "REJECT" else "—"),
            }
            counter += 1
            await manager.broadcast(event)

    except WebSocketDisconnect:
        manager.disconnect(ws)


# ─── ENTRY POINT ───
if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info",
    )
