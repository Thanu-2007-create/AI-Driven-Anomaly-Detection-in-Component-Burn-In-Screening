# ============================================================
#  ESS-AI BACKEND — start_server.py
#  Cross-platform Python launcher
# ============================================================
import subprocess
import sys
import os

def main():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    print("\n" + "="*62)
    print("  ESS-AI SPACE RELIABILITY INTELLIGENCE PLATFORM v2.4.1")
    print("  AI-Driven Anomaly Detection — Component Burn-In Screening")
    print("="*62)
    print()

    # Install deps
    print("[1/2] Installing dependencies...")
    subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt", "-q"], check=False)

    print("[2/2] Starting server...")
    print()
    print("  📡 API Docs:    http://localhost:8000/docs")
    print("  📡 ReDoc:       http://localhost:8000/redoc")
    print("  🔌 WebSocket:   ws://localhost:8000/ws/live")
    print("  🌐 Frontend:    Open frontend/index.html in browser")
    print()
    print("  Press Ctrl+C to stop")
    print("="*62 + "\n")

    subprocess.run([sys.executable, "main.py"])

if __name__ == "__main__":
    main()
