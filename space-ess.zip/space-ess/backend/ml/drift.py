# ============================================================
#  ESS-AI BACKEND — ml/drift.py
#  Module B: Time-Series Drift Predictor
#  Models: PolynomialRegression | Ridge | GradientBoosting | Ensemble
# ============================================================
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from sklearn.linear_model import Ridge
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import uuid
from datetime import datetime

from ml.data_gen import SPACECRAFT_TESTS


class DriftPredictor:
    """
    Module B — Time-Series Drift Predictor.

    Takes V_0h and V_24h (early burn-in readings) and predicts V_168h.
    If the predicted drift rate δ = (V_pred_168h - V_0h) / 168h
    exceeds the safety slope Sₗᵢₘ = μ_lot × slope_mult,
    the component is flagged for early rejection.

    Early rejection at 24h saves 144h of burn-in time while
    preventing latent defects from reaching payloads.
    """

    def __init__(
        self,
        slope_multiplier: float = 0.003,
        model_type: str = "ensemble",
        degree: int = 3,
    ):
        self.slope_multiplier = slope_multiplier
        self.model_type = model_type
        self.degree = degree
        self._poly_model = None
        self._ridge_model = None
        self._gbr_model = None
        self._is_trained = False

    def _build_features(self, df: pd.DataFrame) -> np.ndarray:
        """
        Engineer features from V_0h and V_24h readings.
        X = [V_0h, V_24h, ΔV, rate_24h, V_0h², ΔV²]
        """
        v0 = df["value_0h"].values.astype(float)
        v24 = df["value_24h"].values.astype(float)
        delta = v24 - v0
        rate = delta / 24.0
        return np.column_stack([v0, v24, delta, rate, v0**2, delta**2])

    def _build_poly_pipeline(self, degree: int) -> Pipeline:
        return Pipeline([
            ("scaler", StandardScaler()),
            ("poly", PolynomialFeatures(degree=degree, include_bias=False)),
            ("ridge", Ridge(alpha=1.0)),
        ])

    def _build_ridge_pipeline(self) -> Pipeline:
        return Pipeline([
            ("scaler", StandardScaler()),
            ("ridge", Ridge(alpha=10.0)),
        ])

    def _build_gbr_model(self) -> GradientBoostingRegressor:
        return GradientBoostingRegressor(
            n_estimators=100,
            max_depth=4,
            learning_rate=0.05,
            subsample=0.8,
            random_state=42,
        )

    def train(self, df: pd.DataFrame):
        """Train all sub-models on the given dataset."""
        X = self._build_features(df)
        y = df["value_168h"].values.astype(float)

        # Filter rows with valid 168h measurements
        valid = ~np.isnan(y)
        X, y = X[valid], y[valid]

        if len(X) < 5:
            return

        self._poly_model = self._build_poly_pipeline(self.degree)
        self._poly_model.fit(X, y)

        self._ridge_model = self._build_ridge_pipeline()
        self._ridge_model.fit(X, y)

        self._gbr_model = self._build_gbr_model()
        self._gbr_model.fit(X, y)

        self._is_trained = True

    def predict_single(
        self,
        v0: float,
        v24: float,
        lot_mean: float,
    ) -> Dict:
        """Predict V_168h and drift flag for a single component."""
        delta = v24 - v0
        rate = delta / 24.0
        X = np.array([[v0, v24, delta, rate, v0**2, delta**2]])

        preds = []
        if self._poly_model:
            preds.append(float(self._poly_model.predict(X)[0]))
        if self._ridge_model:
            preds.append(float(self._ridge_model.predict(X)[0]))
        if self._gbr_model:
            preds.append(float(self._gbr_model.predict(X)[0]))

        if not preds:
            # Fallback: simple linear extrapolation
            pred = v0 + rate * 168
        elif self.model_type == "poly" and self._poly_model:
            pred = float(self._poly_model.predict(X)[0])
        elif self.model_type == "ridge" and self._ridge_model:
            pred = float(self._ridge_model.predict(X)[0])
        elif self.model_type == "gbr" and self._gbr_model:
            pred = float(self._gbr_model.predict(X)[0])
        else:
            pred = float(np.mean(preds))

        drift_rate = (pred - v0) / 168.0
        safety_slope = lot_mean * abs(self.slope_multiplier)
        drift_flag = drift_rate > safety_slope

        # Confidence: higher when models agree
        if len(preds) > 1:
            std_pred = np.std(preds)
            conf = max(0.5, 1.0 - std_pred / (abs(pred) + 1e-10))
        else:
            conf = 0.75

        return {
            "pred_168h": round(pred, 6),
            "drift_rate": round(drift_rate, 8),
            "safety_slope": round(safety_slope, 8),
            "drift_flag": bool(drift_flag),
            "confidence": round(float(conf), 4),
            "model_predictions": {
                "poly": round(preds[0], 5) if len(preds) > 0 else None,
                "ridge": round(preds[1], 5) if len(preds) > 1 else None,
                "gbr": round(preds[2], 5) if len(preds) > 2 else None,
                "ensemble": round(float(np.mean(preds)), 5) if preds else None,
            },
        }

    def analyze(self, df: pd.DataFrame) -> Dict:
        """
        Run full Module B analysis on a DataFrame.
        Trains the model on available data and runs predictions.
        """
        run_id = f"MOD-B-{uuid.uuid4().hex[:10].upper()}"
        df = df.copy()

        # Train on components that have 168h readings
        has_168 = df["value_168h"].notna()
        if has_168.sum() > 5:
            self.train(df[has_168])

        lot_mean = df["lot_mean"].mean() if "lot_mean" in df.columns else df["value_0h"].mean()
        safety_slope = lot_mean * abs(self.slope_multiplier)

        # Build predictions for all
        X = self._build_features(df)
        predictions = {}
        if self._is_trained:
            if self._poly_model:
                predictions["poly"] = self._poly_model.predict(X).tolist()
            if self._ridge_model:
                predictions["ridge"] = self._ridge_model.predict(X).tolist()
            if self._gbr_model:
                predictions["gbr"] = self._gbr_model.predict(X).tolist()

        if predictions:
            all_preds = np.array(list(predictions.values()))
            ensemble_pred = all_preds.mean(axis=0)
            pred_std = all_preds.std(axis=0)
        else:
            # Fallback: linear extrapolation
            v0 = df["value_0h"].values
            v24 = df["value_24h"].values
            rate = (v24 - v0) / 24.0
            ensemble_pred = v0 + rate * 168
            pred_std = np.zeros_like(ensemble_pred)

        if self.model_type in predictions:
            final_pred = np.array(predictions[self.model_type])
        else:
            final_pred = ensemble_pred

        drift_rates = (final_pred - df["value_0h"].values) / 168.0
        drift_flags = drift_rates > safety_slope

        # Metrics vs actual 168h
        actual = df["value_168h"].values
        valid_mask = ~np.isnan(actual)
        mae = rmse = r2 = None
        if valid_mask.sum() > 2:
            mae = float(mean_absolute_error(actual[valid_mask], final_pred[valid_mask]))
            rmse = float(np.sqrt(mean_squared_error(actual[valid_mask], final_pred[valid_mask])))
            r2 = float(r2_score(actual[valid_mask], final_pred[valid_mask]))

        # Per-component results
        components = []
        for i, (_, row) in enumerate(df.iterrows()):
            conf = max(0.5, 1.0 - pred_std[i] / (abs(final_pred[i]) + 1e-10)) if pred_std[i] > 0 else 0.85
            components.append({
                "component_id": row.get("component_id", f"COMP-{i:05d}"),
                "lot_id": row.get("lot_id", "UNKNOWN"),
                "parameter": row.get("parameter", "UNKNOWN"),
                "value_0h": round(float(row.get("value_0h", 0)), 5),
                "value_24h": round(float(row.get("value_24h", 0)), 5),
                "value_96h": round(float(row.get("value_96h", 0)), 5) if pd.notna(row.get("value_96h")) else None,
                "value_168h": round(float(row.get("value_168h", 0)), 5) if pd.notna(row.get("value_168h")) else None,
                "pred_value_168h": round(float(final_pred[i]), 5),
                "pred_error": round(float(abs(final_pred[i] - row.get("value_168h", final_pred[i]))), 5),
                "drift_rate": round(float(drift_rates[i]), 8),
                "safety_slope": round(float(safety_slope), 8),
                "drift_flag": bool(drift_flags[i]),
                "lot_mean": round(float(lot_mean), 5),
                "lot_sigma": round(float(df["lot_sigma"].mean() if "lot_sigma" in df.columns else 1.0), 5),
                "z_score": 0.0,
                "z_flag": False,
                "iqr_flag": False,
                "modified_z_flag": False,
                "isoforest_flag": False,
                "lof_flag": False,
                "vote_count": 0,
                "ensemble_flag": bool(drift_flags[i]),
                "is_hard_fail": False,
                "is_latent": False,
                "anomaly_score": min(100, round(float(drift_rates[i] / safety_slope * 50), 2)) if safety_slope > 0 else 0,
                "final_decision": "REJECT" if drift_flags[i] else "PASS",
                "confidence": round(float(conf), 4),
                "model_predictions": {
                    "poly": round(float(predictions["poly"][i]), 5) if "poly" in predictions else None,
                    "ridge": round(float(predictions["ridge"][i]), 5) if "ridge" in predictions else None,
                    "gbr": round(float(predictions["gbr"][i]), 5) if "gbr" in predictions else None,
                    "ensemble": round(float(ensemble_pred[i]), 5),
                },
            })

        return {
            "run_id": run_id,
            "lot_id": df["lot_id"].iloc[0] if "lot_id" in df.columns else "ALL",
            "parameter": df["parameter"].iloc[0] if "parameter" in df.columns else "MIXED",
            "model_type": self.model_type,
            "slope_multiplier": self.slope_multiplier,
            "mae": round(mae, 5) if mae else None,
            "rmse": round(rmse, 5) if rmse else None,
            "r_squared": round(r2, 5) if r2 else None,
            "drift_flags": int(drift_flags.sum()),
            "safety_slope_limit": round(float(safety_slope), 8),
            "lot_mean": round(float(lot_mean), 5),
            "total": len(df),
            "components": components,
            "timestamp": datetime.utcnow().isoformat(),
        }
