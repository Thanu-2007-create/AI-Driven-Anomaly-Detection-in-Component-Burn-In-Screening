# ============================================================
#  ESS-AI BACKEND — ml/explainer.py
#  XAI Explainability Engine — SHAP + NLG Justifications
# ============================================================
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Any
import uuid

from ml.data_gen import SPACECRAFT_TESTS

# SHAP features and their human-readable descriptions
FEATURE_NAMES = [
    "Z-Score magnitude",
    "Drift rate (ΔV/168h)",
    "IQR fence breach",
    "V_0h lot deviation",
    "V_24h rate of rise",
    "Isolation Forest score",
    "LOF density score",
]

FEATURE_DESCRIPTIONS = {
    "Z-Score magnitude": "Deviation from lot mean in standard deviations. Primary dynamic outlier signal.",
    "Drift rate (ΔV/168h)": "Rate of parametric change per hour under burn-in stress. Key latent defect signal.",
    "IQR fence breach": "Whether the component value exceeds Q3 + 1.5×IQR — non-parametric outlier boundary.",
    "V_0h lot deviation": "Absolute deviation of initial reading from the lot production mean (µA).",
    "V_24h rate of rise": "Early burn-in rate signal (0h→24h). Predictor for 168h endpoint behavior.",
    "Isolation Forest score": "Isolation Forest anomaly score — measures ease of isolation from normal cluster.",
    "LOF density score": "Local Outlier Factor — measures local density deviation in feature space.",
}


class SHAPExplainer:
    """
    XAI Engine — Produces SHAP-style feature attributions and
    plain-language QA justifications for every screening decision.
    """

    def _compute_shap_approx(
        self,
        component: Dict,
        lot_mean: float,
        lot_sigma: float,
        iqr_upper: float,
        safety_slope: float,
    ) -> Dict[str, float]:
        """
        Compute approximate SHAP values via analytical feature attribution.
        We compute the marginal contribution of each feature to the anomaly score.
        """
        v0 = component.get("value_0h", lot_mean)
        v24 = component.get("value_24h", v0)
        z = abs(component.get("z_score", (v0 - lot_mean) / max(lot_sigma, 1e-10)))
        drift = component.get("drift_rate", 0.0) or 0.0
        iqr_flag = component.get("iqr_flag", False)
        iso_flag = component.get("isoforest_flag", False)
        lof_flag = component.get("lof_flag", False)

        # Base value = average anomaly score for normal components (~20)
        base = 20.0

        shap = {
            "Z-Score magnitude": round((z / 3.0) * 35 if z > 3 else (z / 3.0) * 10 - 5, 3),
            "Drift rate (ΔV/168h)": round(
                (drift / max(safety_slope, 1e-10) - 1) * 25 if drift > safety_slope else (drift / max(safety_slope, 1e-10) - 1) * 15, 3
            ),
            "IQR fence breach": round(22.0 if iqr_flag else -8.0, 3),
            "V_0h lot deviation": round(((v0 - lot_mean) / max(lot_sigma, 1e-10)) * 8, 3),
            "V_24h rate of rise": round(((v24 - v0) / 24.0 / max(lot_mean * 0.003, 1e-10) - 1) * 10, 3),
            "Isolation Forest score": round(15.0 if iso_flag else -5.0, 3),
            "LOF density score": round(15.0 if lof_flag else -5.0, 3),
        }

        return shap

    def _generate_nlg_justification(
        self,
        component: Dict,
        shap_values: Dict[str, float],
        lot_mean: float,
        lot_sigma: float,
        safety_slope: float,
        test_spec: Optional[Dict] = None,
    ) -> str:
        """Generate plain-language QA inspector justification."""
        cid = component.get("component_id", "UNKNOWN")
        param = component.get("parameter", "PARAM")
        decision = component.get("final_decision", "UNKNOWN")
        v0 = component.get("value_0h", 0)
        v24 = component.get("value_24h", 0)
        v168 = component.get("value_168h", 0)
        pred168 = component.get("pred_value_168h")
        z = component.get("z_score", 0)
        drift = component.get("drift_rate", 0) or 0
        drift_flag = component.get("drift_flag", False)
        iqr_flag = component.get("iqr_flag", False)
        unit = test_spec.get("unit", "µA") if test_spec else "µA"
        abs_max = component.get("abs_limit_max")

        lines = []

        # Opening
        if decision == "PASS":
            lines.append(
                f"[PASS] Component {cid} ({param}) has been CLEARED for payload integration. "
                f"All three ensemble detectors (Z-Score, IQR, IsolationForest) voted nominal."
            )
        elif decision == "REJECT":
            lines.append(
                f"[REJECT] Component {cid} ({param}) has been REJECTED by the ESS-AI screening system. "
                f"This component must be quarantined and must NOT be released to payload integration."
            )
        else:
            lines.append(
                f"[MARGINAL] Component {cid} ({param}) is in a MARGINAL state requiring QA engineer review."
            )

        # Z-Score finding
        if abs(z) > 3.0:
            lines.append(
                f"CRITICAL: The measured {param} at 0h ({v0:.4f} {unit}) is {abs(z):.2f} standard deviations "
                f"above the lot mean ({lot_mean:.4f} {unit}). This is a strong dynamic outlier signal. "
                f"Even though the absolute limit ({abs_max} {unit}) may not be breached, "
                f"this component is anomalous relative to its production lot."
            )
        elif abs(z) > 2.0:
            lines.append(
                f"CAUTION: Z-Score of {z:.2f}σ is in the elevated range (2–3σ). "
                f"Component sits at the {abs(z/3*100):.0f}th percentile of lot deviation."
            )
        else:
            lines.append(
                f"Z-Score of {z:.2f}σ is within normal range (< 2σ). No static anomaly detected."
            )

        # IQR finding
        if iqr_flag:
            lines.append(
                f"IQR FENCE BREACH: The value ({v0:.4f} {unit}) exceeds the lot IQR upper fence "
                f"(Q3 + 1.5×IQR). This non-parametric test confirms the outlier finding independently of Gaussian assumptions."
            )

        # Drift finding
        if drift_flag:
            lines.append(
                f"DRIFT WARNING (Module B): Predicted drift rate δ = {drift*1000:.4f} µA/h (×1e-3) "
                f"exceeds the safety slope limit Sₗᵢₘ = {safety_slope*1000:.4f} µA/h (×1e-3). "
                f"The 168h predicted value ({pred168:.4f} {unit} if pred168 else 'N/A') indicates "
                f"accelerating parametric degradation characteristic of a latent defect."
            )
        elif decision == "REJECT":
            lines.append(
                f"MODULE B DRIFT: Drift rate is within safety slope limit, "
                f"but Module A anomaly detection triggered the REJECT decision."
            )

        # Static limit check
        if abs_max and v168 and v168 > abs_max:
            lines.append(
                f"HARD LIMIT BREACH: V_168h = {v168:.4f} {unit} exceeds the absolute datasheet maximum "
                f"of {abs_max} {unit}. This component would fail even static screening."
            )
        elif abs_max and v0 < abs_max and decision == "REJECT":
            lines.append(
                f"LATENT DEFECT CONFIRMED: V_0h = {v0:.4f} {unit} passes the absolute datasheet limit "
                f"({abs_max} {unit}). This component would have ESCAPED traditional static screening. "
                f"Dynamic detection prevented a potential in-flight failure."
            )

        # Top contributing feature
        top_feat = max(shap_values, key=lambda k: abs(shap_values[k]))
        top_val = shap_values[top_feat]
        lines.append(
            f"TOP CONTRIBUTING FEATURE: '{top_feat}' (SHAP = {top_val:+.3f}) — "
            f"{FEATURE_DESCRIPTIONS.get(top_feat, 'Key anomaly signal.')}"
        )

        # Recommendation
        if decision == "REJECT":
            lines.append(
                "RECOMMENDATION: Immediately quarantine this component. Do not release to payload integration. "
                "Retain for failure analysis to identify root cause (oxide integrity / junction defect / radiation damage). "
                "Consider re-screening adjacent components from the same wafer sub-batch."
            )
        elif decision == "MARGINAL":
            lines.append(
                "RECOMMENDATION: Flag for extended monitoring. Consider 200h extended burn-in screening "
                "and re-measurement before payload integration decision."
            )
        else:
            lines.append(
                "RECOMMENDATION: Component cleared for payload integration. "
                "No further ESS action required. Confidence: NOMINAL."
            )

        return "\n".join([f"{i+1}. {line}" for i, line in enumerate(lines)])

    def explain_component(
        self,
        component: Dict,
        lot_mean: float,
        lot_sigma: float,
        iqr_upper: float,
        safety_slope: float,
        param: Optional[str] = None,
    ) -> Dict:
        """Generate full XAI explanation for a single component."""
        test_spec = SPACECRAFT_TESTS.get(param or component.get("parameter", "IDDQ"))

        shap_values = self._compute_shap_approx(
            component, lot_mean, lot_sigma, iqr_upper, safety_slope
        )

        top_feature = max(shap_values, key=lambda k: abs(shap_values[k]))
        top_shap = shap_values[top_feature]
        base_value = 20.0
        total_score = base_value + sum(shap_values.values())

        nlg = self._generate_nlg_justification(
            component, shap_values, lot_mean, lot_sigma, safety_slope, test_spec
        )

        feature_values = {
            "Z-Score magnitude": abs(component.get("z_score", 0)),
            "Drift rate (ΔV/168h)": abs(component.get("drift_rate", 0) or 0),
            "IQR fence breach": 1.0 if component.get("iqr_flag") else 0.0,
            "V_0h lot deviation": abs(component.get("value_0h", lot_mean) - lot_mean),
            "V_24h rate of rise": abs((component.get("value_24h", component.get("value_0h", 0)) - component.get("value_0h", 0)) / 24.0),
            "Isolation Forest score": 1.0 if component.get("isoforest_flag") else 0.0,
            "LOF density score": 1.0 if component.get("lof_flag") else 0.0,
        }

        return {
            "component_id": component.get("component_id", "UNKNOWN"),
            "lot_id": component.get("lot_id", "UNKNOWN"),
            "parameter": component.get("parameter", "UNKNOWN"),
            "final_decision": component.get("final_decision", "UNKNOWN"),
            "base_value": base_value,
            "shap_values": shap_values,
            "feature_values": feature_values,
            "top_feature": top_feature,
            "top_shap": round(top_shap, 4),
            "computed_score": round(total_score, 2),
            "decision_reason": nlg,
            "anomaly_score": component.get("anomaly_score", 0),
            "confidence": component.get("confidence", 0.75),
            "feature_descriptions": FEATURE_DESCRIPTIONS,
        }

    def explain_batch(
        self,
        components: List[Dict],
        lot_mean: float,
        lot_sigma: float,
        iqr_upper: float,
        safety_slope: float,
        param: Optional[str] = None,
    ) -> Dict:
        """Run XAI explanation on all flagged components."""
        flagged = [c for c in components if c.get("final_decision") in ("REJECT", "MARGINAL")]
        explanations = [
            self.explain_component(c, lot_mean, lot_sigma, iqr_upper, safety_slope, param)
            for c in flagged[:50]  # cap for performance
        ]

        # Global feature importance (mean absolute SHAP)
        all_shap = {}
        for exp in explanations:
            for feat, val in exp["shap_values"].items():
                all_shap.setdefault(feat, []).append(abs(val))
        global_importance = {feat: round(np.mean(vals), 4) for feat, vals in all_shap.items()}

        return {
            "explanations": explanations,
            "global_feature_importance": global_importance,
            "n_explained": len(explanations),
            "feature_descriptions": FEATURE_DESCRIPTIONS,
        }
