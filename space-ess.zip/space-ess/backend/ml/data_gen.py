# ============================================================
#  ESS-AI BACKEND — ml/data_gen.py
#  Synthetic Spacecraft ESS Dataset Generator
# ============================================================
import numpy as np
import pandas as pd
from typing import List, Dict, Optional
import uuid

# ─── SPACECRAFT TEST PARAMETER CATALOG ───
SPACECRAFT_TESTS = {
    "IDDQ": {
        "name": "Quiescent Standby Current",
        "category": "ELECTRICAL",
        "unit": "µA",
        "typical": 10.0,
        "sigma": 1.5,
        "abs_max": 50.0,
        "abs_min": 0.0,
        "safety_slope_mult": 0.003,
        "standard": "MIL-STD-883K Method 1015",
        "description": "Static CMOS standby current indicating gate oxide integrity.",
    },
    "ILEAK": {
        "name": "Gate/Junction Leakage Current",
        "category": "ELECTRICAL",
        "unit": "µA",
        "typical": 8.0,
        "sigma": 1.2,
        "abs_max": 40.0,
        "abs_min": 0.0,
        "safety_slope_mult": 0.003,
        "standard": "MIL-STD-883K Method 1015",
        "description": "Reverse-biased junction leakage under elevated temperature stress.",
    },
    "TPROP": {
        "name": "Propagation Delay",
        "category": "TIMING",
        "unit": "ns",
        "typical": 5.2,
        "sigma": 0.3,
        "abs_max": 8.0,
        "abs_min": 0.0,
        "safety_slope_mult": 0.002,
        "standard": "JEDEC JESD22-A108",
        "description": "Gate propagation delay indicating channel degradation under thermal stress.",
    },
    "VTH_N": {
        "name": "NMOS Threshold Voltage",
        "category": "ELECTRICAL",
        "unit": "V",
        "typical": 0.45,
        "sigma": 0.02,
        "abs_max": 0.65,
        "abs_min": 0.25,
        "safety_slope_mult": 0.001,
        "standard": "ECSS-Q-ST-60C",
        "description": "N-channel MOSFET threshold voltage — NBT stress indicator.",
    },
    "VTH_P": {
        "name": "PMOS Threshold Voltage",
        "category": "ELECTRICAL",
        "unit": "V",
        "typical": -0.42,
        "sigma": 0.02,
        "abs_max": -0.28,
        "abs_min": -0.65,
        "safety_slope_mult": 0.001,
        "standard": "ECSS-Q-ST-60C",
        "description": "P-channel MOSFET threshold voltage — PBTI stress indicator.",
    },
    "ICC": {
        "name": "Active Supply Current",
        "category": "ELECTRICAL",
        "unit": "mA",
        "typical": 15.0,
        "sigma": 2.0,
        "abs_max": 35.0,
        "abs_min": 5.0,
        "safety_slope_mult": 0.004,
        "standard": "MIL-STD-883K",
        "description": "Active operating supply current — electromigration / hot-carrier indicator.",
    },
    "VOUT": {
        "name": "Output Voltage Swing",
        "category": "ELECTRICAL",
        "unit": "V",
        "typical": 3.28,
        "sigma": 0.05,
        "abs_max": 3.6,
        "abs_min": 3.0,
        "safety_slope_mult": 0.0005,
        "standard": "MIL-STD-883K Method 2011",
        "description": "Logic output high/low voltage swing — drive strength degradation monitor.",
    },
    "CMRR": {
        "name": "Common-Mode Rejection Ratio",
        "category": "ELECTRICAL",
        "unit": "dB",
        "typical": 90.0,
        "sigma": 3.0,
        "abs_max": 120.0,
        "abs_min": 60.0,
        "safety_slope_mult": -0.002,
        "standard": "ECSS-Q-ST-60C",
        "description": "Differential amplifier CMRR — aging degrades noise immunity.",
    },
    "PSRR": {
        "name": "Power Supply Rejection Ratio",
        "category": "ELECTRICAL",
        "unit": "dB",
        "typical": 85.0,
        "sigma": 4.0,
        "abs_max": 120.0,
        "abs_min": 55.0,
        "safety_slope_mult": -0.002,
        "standard": "MIL-STD-202",
        "description": "PSRR degradation indicates bias circuit aging under sustained thermal stress.",
    },
    "TSETUP": {
        "name": "Setup Time Margin",
        "category": "TIMING",
        "unit": "ps",
        "typical": 180.0,
        "sigma": 15.0,
        "abs_max": 350.0,
        "abs_min": 80.0,
        "safety_slope_mult": 0.003,
        "standard": "JEDEC JESD22-A108",
        "description": "Flip-flop setup time — degradation implies clock margin erosion.",
    },
    "THOLD": {
        "name": "Hold Time Margin",
        "category": "TIMING",
        "unit": "ps",
        "typical": 120.0,
        "sigma": 12.0,
        "abs_max": 250.0,
        "abs_min": 40.0,
        "safety_slope_mult": 0.003,
        "standard": "JEDEC JESD22-A108",
        "description": "Flip-flop hold time — increases under NBTI degradation.",
    },
    "TID": {
        "name": "Total Ionizing Dose",
        "category": "RADIATION",
        "unit": "krad(Si)",
        "typical": 0.5,
        "sigma": 0.1,
        "abs_max": 3.0,
        "abs_min": 0.0,
        "safety_slope_mult": 0.005,
        "standard": "MIL-STD-1019 / ESCC 22900",
        "description": "Accumulated ionizing radiation dose causing flat-band voltage shift.",
    },
    "SEL": {
        "name": "Single-Event Latchup Current",
        "category": "RADIATION",
        "unit": "mA",
        "typical": 0.2,
        "sigma": 0.05,
        "abs_max": 2.0,
        "abs_min": 0.0,
        "safety_slope_mult": 0.006,
        "standard": "ECSS-Q-ST-60-15C / MIL-STD-750",
        "description": "SEL susceptibility screening — abnormal latchup current post heavy-ion exposure.",
    },
    "ESD_HBM": {
        "name": "ESD HBM Failure Threshold",
        "category": "MECHANICAL",
        "unit": "V",
        "typical": 2000.0,
        "sigma": 150.0,
        "abs_max": 4000.0,
        "abs_min": 1000.0,
        "safety_slope_mult": -0.002,
        "standard": "AEC-Q100-002 / MIL-STD-883K Method 3015",
        "description": "Human Body Model ESD robustness — screening for oxide damage pre-integration.",
    },
    "TEMP_CYCLE": {
        "name": "Thermal Cycling Delta (ΔR)",
        "category": "MECHANICAL",
        "unit": "mΩ",
        "typical": 0.5,
        "sigma": 0.15,
        "abs_max": 3.0,
        "abs_min": 0.0,
        "safety_slope_mult": 0.01,
        "standard": "MIL-STD-883K Method 1010 / ECSS-Q-ST-70-04C",
        "description": "Resistance delta post thermal cycling — mechanical fatigue / solder joint indicator.",
    },
}

LOT_IDS = ["LOT-A77", "LOT-B12", "LOT-C34", "LOT-D91", "LOT-E55", "LOT-F03",
           "LOT-G18", "LOT-H42", "LOT-J07", "LOT-K63", "LOT-L29", "LOT-M84"]


def normal_random(mean: float, std: float) -> float:
    """Box-Muller normal variate."""
    u = max(1e-10, np.random.random())
    v = np.random.random()
    return mean + std * np.sqrt(-2 * np.log(u)) * np.cos(2 * np.pi * v)


def generate_time_series(
    base_val: float,
    sigma: float,
    is_latent: bool = False,
    is_hard_fail: bool = False,
    is_rad_fail: bool = False,
) -> Dict[str, float]:
    """
    Generate realistic burn-in time-series for a single component.
    Returns {v0h, v24h, v96h, v168h}.
    """
    v0 = normal_random(base_val, sigma)

    if is_hard_fail:
        v0 = normal_random(base_val * 4.0, sigma * 2.0)
        v24 = v0 * normal_random(1.06, 0.02)
        v96 = v24 * normal_random(1.08, 0.02)
        v168 = v96 * normal_random(1.10, 0.02)

    elif is_latent:
        # Appears marginal at 0h but drifts strongly
        v0 = normal_random(base_val * normal_random(3.2, 0.4), sigma * 1.3)
        v24 = v0 * normal_random(1.08, 0.03)
        v96 = v24 * normal_random(1.13, 0.04)
        v168 = v96 * normal_random(1.16, 0.05)

    elif is_rad_fail:
        # Radiation-induced: step degradation
        v0 = normal_random(base_val, sigma)
        v24 = v0 + normal_random(base_val * 0.15, sigma * 0.5)
        v96 = v24 + normal_random(base_val * 0.20, sigma * 0.5)
        v168 = v96 + normal_random(base_val * 0.25, sigma * 0.6)

    else:
        # Nominal aging: very slight upward drift
        v24 = v0 * normal_random(1.005, 0.008)
        v96 = v24 * normal_random(1.008, 0.008)
        v168 = v96 * normal_random(1.010, 0.008)

    return {
        "value_0h": round(v0, 6),
        "value_24h": round(v24, 6),
        "value_96h": round(v96, 6),
        "value_168h": round(v168, 6),
    }


def generate_dataset(
    n_lots: int = 6,
    components_per_lot_param: int = 40,
    latent_defect_rate: float = 0.04,
    hard_fail_rate: float = 0.02,
    parameters: Optional[List[str]] = None,
    seed: int = 42,
) -> pd.DataFrame:
    """
    Generate a synthetic ESS dataset covering n_lots × parameters.
    Returns a DataFrame with one row per component measurement.
    """
    np.random.seed(seed)
    if parameters is None:
        parameters = list(SPACECRAFT_TESTS.keys())

    records = []
    comp_idx = 1

    lot_list = LOT_IDS[:n_lots]

    for lot_id in lot_list:
        for param in parameters:
            spec = SPACECRAFT_TESTS[param]
            base = spec["typical"]
            sigma = spec["sigma"]
            abs_max = spec["abs_max"]
            abs_min = spec["abs_min"]

            for i in range(components_per_lot_param):
                rnd = np.random.random()
                is_hard = rnd < hard_fail_rate
                is_latent = (not is_hard) and (rnd < hard_fail_rate + latent_defect_rate)
                is_rad = (not is_hard) and (not is_latent) and (rnd < hard_fail_rate + latent_defect_rate + 0.01) \
                         and param in ("TID", "SEL")

                ts = generate_time_series(base, sigma, is_latent, is_hard, is_rad)
                v0 = ts["value_0h"]
                v168 = ts["value_168h"]

                drift_rate = (v168 - v0) / 168.0
                safety_slope = base * abs(spec["safety_slope_mult"])

                component_id = f"{lot_id}-{param}-{comp_idx:05d}"
                comp_idx += 1

                records.append({
                    "component_id": component_id,
                    "lot_id": lot_id,
                    "parameter": param,
                    "unit": spec["unit"],
                    "category": spec["category"],
                    "value_0h": ts["value_0h"],
                    "value_24h": ts["value_24h"],
                    "value_96h": ts["value_96h"],
                    "value_168h": ts["value_168h"],
                    "abs_limit_max": abs_max,
                    "abs_limit_min": abs_min,
                    "lot_mean_ref": base,
                    "lot_sigma_ref": sigma,
                    "drift_rate": round(drift_rate, 8),
                    "safety_slope": round(safety_slope, 8),
                    "is_hard_fail_gt": is_hard,
                    "is_latent_gt": is_latent,
                    "is_rad_fail_gt": is_rad,
                })

    df = pd.DataFrame(records)
    return df


def compute_lot_stats(df: pd.DataFrame) -> pd.DataFrame:
    """Compute lot-level statistics and Z-scores per (lot, parameter)."""
    lot_stats = df.groupby(["lot_id", "parameter"])["value_0h"].agg(["mean", "std"]).reset_index()
    lot_stats.columns = ["lot_id", "parameter", "lot_mean", "lot_sigma"]
    lot_stats["lot_sigma"] = lot_stats["lot_sigma"].fillna(1.0).replace(0, 1.0)

    df = df.merge(lot_stats, on=["lot_id", "parameter"], how="left")
    df["z_score"] = (df["value_0h"] - df["lot_mean"]) / df["lot_sigma"]
    df["z_score"] = df["z_score"].round(4)
    return df


def get_test_catalog() -> List[Dict]:
    """Return the full spacecraft test catalog as a list of dicts."""
    result = []
    for code, spec in SPACECRAFT_TESTS.items():
        result.append({
            "test_code": code,
            "test_name": spec["name"],
            "category": spec["category"],
            "unit": spec["unit"],
            "typical_value": spec["typical"],
            "abs_max_limit": spec["abs_max"],
            "abs_min_limit": spec["abs_min"],
            "safety_slope_multiplier": spec["safety_slope_mult"],
            "standard": spec["standard"],
            "description": spec["description"],
        })
    return result
