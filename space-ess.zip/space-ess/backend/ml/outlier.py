# ============================================================
#  ESS-AI BACKEND — ml/outlier.py
#  Module A: Dynamic Outlier Detection Engine
#  Methods: Z-Score | IQR | IsolationForest | LOF | Ensemble
# ============================================================
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.preprocessing import StandardScaler
import uuid
from datetime import datetime

from ml.data_gen import SPACECRAFT_TESTS


class DynamicOutlierDetector:
    """
    Module A — Dynamic Outlier Detection System.

    Unlike static pass/fail, this system detects anomalies relative
    to the production lot distribution — catching latent defects that
    static absolute limits completely miss.
    """

    def __init__(
        self,
        z_threshold: float = 3.0,
        iqr_multiplier: float = 1.5,
        contamination: float = 0.05,
        method: str = "ensemble",
    ):
        self.z_threshold = z_threshold
        self.iqr_multiplier = iqr_multiplier
        self.contamination = contamination
        self.method = method
        self._iso_model: Optional[IsolationForest] = None
        self._lof_model: Optional[LocalOutlierFactor] = None
        self._scaler = StandardScaler()
        self._fit = False

    # ─── INDIVIDUAL DETECTORS ───
    def _z_score_detect(self, values: np.ndarray, mean: float, std: float) -> np.ndarray:
        """Flag components where |Z| > threshold."""
        std = max(std, 1e-10)
        z = np.abs((values - mean) / std)
        return z > self.z_threshold, z

    def _iqr_detect(self, values: np.ndarray) -> Tuple[np.ndarray, float, float]:
        """IQR fence outlier detection."""
        q1 = np.percentile(values, 25)
        q3 = np.percentile(values, 75)
        iqr = q3 - q1
        upper = q3 + self.iqr_multiplier * iqr
        lower = q1 - self.iqr_multiplier * iqr
        flags = (values > upper) | (values < lower)
        return flags, upper, lower

    def _isolation_forest_detect(self, features: np.ndarray) -> np.ndarray:
        """Isolation Forest — unsupervised anomaly detection."""
        model = IsolationForest(
            contamination=self.contamination,
            random_state=42,
            n_estimators=100,
        )
        preds = model.fit_predict(features)
        return preds == -1  # -1 = anomaly

    def _lof_detect(self, features: np.ndarray) -> np.ndarray:
        """Local Outlier Factor — density-based outlier detection."""
        n_neighbors = min(20, len(features) - 1)
        model = LocalOutlierFactor(
            n_neighbors=n_neighbors,
            contamination=self.contamination,
        )
        preds = model.fit_predict(features)
        return preds == -1

    def _modified_z_detect(self, values: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Modified Z-score using median absolute deviation (robust to outliers)."""
        median = np.median(values)
        mad = np.median(np.abs(values - median))
        mad = max(mad, 1e-10)
        modified_z = 0.6745 * np.abs(values - median) / mad
        return modified_z > 3.5, modified_z

    # ─── ANOMALY SCORE ───
    def _compute_anomaly_score(
        self,
        z_abs: np.ndarray,
        iqr_flags: np.ndarray,
        iso_flags: np.ndarray,
        lof_flags: np.ndarray,
        z_threshold: float,
    ) -> np.ndarray:
        """Composite anomaly score 0–100."""
        z_score_component = np.clip(z_abs / z_threshold * 40, 0, 55)
        iqr_component = iqr_flags.astype(float) * 25
        iso_component = iso_flags.astype(float) * 15
        lof_component = lof_flags.astype(float) * 15
        score = z_score_component + iqr_component + iso_component * 0.6 + lof_component * 0.6
        return np.clip(score, 0, 100).round(2)

    # ─── MAIN ANALYSIS ───
    def analyze(
        self,
        df: pd.DataFrame,
        time_point: str = "value_0h",
    ) -> Dict:
        """
        Run full Module A analysis on a DataFrame.
        df must have columns: component_id, lot_id, parameter, value_0h, ..., lot_mean, lot_sigma

        Returns comprehensive results dict.
        """
        run_id = f"MOD-A-{uuid.uuid4().hex[:10].upper()}"
        df = df.copy()

        if time_point not in df.columns:
            time_point = "value_0h"

        values = df[time_point].values.astype(float)
        mean = df["lot_mean"].mean() if "lot_mean" in df.columns else values.mean()
        std = df["lot_sigma"].mean() if "lot_sigma" in df.columns else values.std()
        std = max(std, 1e-10)

        # ── Z-Score
        z_flags, z_abs = self._z_score_detect(values, mean, std)
        individual_z = (values - mean) / std

        # ── IQR
        iqr_flags, iqr_upper, iqr_lower = self._iqr_detect(values)

        # ── Modified Z (Thompson Tau proxy)
        mod_z_flags, mod_z_abs = self._modified_z_detect(values)

        # ── Feature matrix for tree-based methods
        features = np.column_stack([
            values,
            individual_z,
            z_abs,
        ])
        if len(features) > 5:
            iso_flags = self._isolation_forest_detect(features)
            lof_flags = self._lof_detect(features)
        else:
            iso_flags = z_flags.copy()
            lof_flags = z_flags.copy()

        # ── Ensemble vote (≥2 of 4 detectors)
        votes = z_flags.astype(int) + iqr_flags.astype(int) + iso_flags.astype(int) + lof_flags.astype(int)
        if self.method == "zscore":
            ensemble_flags = z_flags
        elif self.method == "iqr":
            ensemble_flags = iqr_flags
        elif self.method == "isoforest":
            ensemble_flags = iso_flags
        elif self.method == "lof":
            ensemble_flags = lof_flags
        else:  # ensemble
            ensemble_flags = votes >= 2

        # ── Anomaly scores
        anomaly_scores = self._compute_anomaly_score(z_abs, iqr_flags, iso_flags, lof_flags, self.z_threshold)

        # ── Final decisions
        abs_limit_max = df.get("abs_limit_max", pd.Series([9999] * len(df))).values
        abs_limit_min = df.get("abs_limit_min", pd.Series([-9999] * len(df))).values
        is_hard_fail = (values > abs_limit_max) | (values < abs_limit_min)
        is_latent = ensemble_flags & ~is_hard_fail

        final_decisions = np.where(
            is_hard_fail, "REJECT",
            np.where(ensemble_flags, "REJECT",
            np.where(anomaly_scores > 50, "MARGINAL", "PASS"))
        )

        # ── Metrics vs ground truth (if available)
        precision = recall = f1 = None
        if "is_hard_fail_gt" in df.columns and "is_latent_gt" in df.columns:
            gt = (df["is_hard_fail_gt"] | df["is_latent_gt"]).values
            pred = ensemble_flags.astype(bool)
            tp = (pred & gt).sum()
            fp = (pred & ~gt).sum()
            fn = (~pred & gt).sum()
            precision = tp / max(tp + fp, 1)
            recall = tp / max(tp + fn, 1)
            f1 = 2 * precision * recall / max(precision + recall, 1e-10)

        # ── Build per-component results
        components = []
        for i, row in df.iterrows():
            idx = df.index.get_loc(i)
            components.append({
                "component_id": row.get("component_id", f"COMP-{idx:05d}"),
                "lot_id": row.get("lot_id", "UNKNOWN"),
                "parameter": row.get("parameter", "UNKNOWN"),
                "value_0h": round(float(row.get("value_0h", 0)), 5),
                "value_24h": round(float(row.get("value_24h", 0)), 5) if pd.notna(row.get("value_24h")) else None,
                "value_96h": round(float(row.get("value_96h", 0)), 5) if pd.notna(row.get("value_96h")) else None,
                "value_168h": round(float(row.get("value_168h", 0)), 5) if pd.notna(row.get("value_168h")) else None,
                "lot_mean": round(float(mean), 5),
                "lot_sigma": round(float(std), 5),
                "z_score": round(float(individual_z[idx]), 4),
                "z_flag": bool(z_flags[idx]),
                "iqr_flag": bool(iqr_flags[idx]),
                "modified_z_flag": bool(mod_z_flags[idx]),
                "isoforest_flag": bool(iso_flags[idx]),
                "lof_flag": bool(lof_flags[idx]),
                "vote_count": int(votes[idx]),
                "ensemble_flag": bool(ensemble_flags[idx]),
                "is_hard_fail": bool(is_hard_fail[idx]),
                "is_latent": bool(is_latent[idx]),
                "anomaly_score": float(anomaly_scores[idx]),
                "final_decision": str(final_decisions[idx]),
                "abs_limit_max": float(abs_limit_max[idx]) if abs_limit_max[idx] < 9000 else None,
                "static_pass": bool(~is_hard_fail[idx]),
                "drift_rate": None,
                "pred_value_168h": None,
                "drift_flag": False,
                "safety_slope": None,
                "confidence": round(min(1.0, anomaly_scores[idx] / 100 + 0.3), 3),
            })

        flagged = ensemble_flags.sum() + is_hard_fail.sum() - (ensemble_flags & is_hard_fail).sum()
        latent_caught = is_latent.sum()

        return {
            "run_id": run_id,
            "lot_id": df["lot_id"].iloc[0] if "lot_id" in df.columns else "ALL",
            "parameter": df["parameter"].iloc[0] if "parameter" in df.columns else "MIXED",
            "method": self.method,
            "z_threshold": self.z_threshold,
            "total": len(df),
            "flagged": int(flagged),
            "passed": int(len(df) - flagged),
            "latent_defects_caught": int(latent_caught),
            "flag_rate": round(flagged / max(len(df), 1) * 100, 2),
            "lot_mean": round(float(mean), 5),
            "lot_sigma": round(float(std), 5),
            "iqr_upper_fence": round(float(iqr_upper), 5),
            "iqr_lower_fence": round(float(iqr_lower), 5),
            "precision": round(precision, 4) if precision is not None else None,
            "recall": round(recall, 4) if recall is not None else None,
            "f1_score": round(f1, 4) if f1 is not None else None,
            "components": components,
            "timestamp": datetime.utcnow().isoformat(),
        }
