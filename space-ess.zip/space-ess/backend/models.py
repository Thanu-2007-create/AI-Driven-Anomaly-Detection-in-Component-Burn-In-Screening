# ============================================================
#  ESS-AI BACKEND — models.py
#  SQLAlchemy ORM Table Definitions
# ============================================================
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text, ForeignKey, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database import Base


class Lot(Base):
    """Production lot / batch of components"""
    __tablename__ = "lots"

    id = Column(Integer, primary_key=True, index=True)
    lot_id = Column(String(20), unique=True, index=True, nullable=False)
    description = Column(String(200), nullable=True)
    device_type = Column(String(100), nullable=True)
    technology_node = Column(String(30), nullable=True)  # e.g. "28nm CMOS"
    burn_in_temp = Column(Float, default=125.0)           # °C
    burn_in_duration = Column(Float, default=168.0)        # hours
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    status = Column(String(20), default="ACTIVE")         # ACTIVE, COMPLETE, HOLD

    components = relationship("Component", back_populates="lot_ref", cascade="all, delete")
    analysis_runs = relationship("AnalysisRun", back_populates="lot_ref")


class Component(Base):
    """Individual electronic component under test"""
    __tablename__ = "components"

    id = Column(Integer, primary_key=True, index=True)
    component_id = Column(String(50), unique=True, index=True, nullable=False)
    lot_id = Column(String(20), ForeignKey("lots.lot_id"), nullable=False)
    parameter = Column(String(20), nullable=False)       # IDDQ, ILEAK, TPROP, etc.
    unit = Column(String(10), default="µA")

    # Burn-in time-point measurements
    value_0h   = Column(Float, nullable=False)
    value_24h  = Column(Float, nullable=True)
    value_96h  = Column(Float, nullable=True)
    value_168h = Column(Float, nullable=True)

    # Lot statistics (computed)
    lot_mean   = Column(Float, nullable=True)
    lot_sigma  = Column(Float, nullable=True)
    z_score    = Column(Float, nullable=True)

    # Absolute limits from datasheet
    abs_limit_max = Column(Float, nullable=True)
    abs_limit_min = Column(Float, nullable=True)

    # Screening decisions
    module_a_flag   = Column(Boolean, default=False)   # Dynamic outlier flag
    module_b_flag   = Column(Boolean, default=False)   # Drift threshold flag
    is_hard_fail    = Column(Boolean, default=False)   # Absolute limit breach
    is_latent_defect= Column(Boolean, default=False)   # Passes static but flagged dynamic
    anomaly_score   = Column(Float, nullable=True)     # 0–100
    drift_rate      = Column(Float, nullable=True)     # µA/h
    pred_value_168h = Column(Float, nullable=True)     # Module B prediction
    confidence      = Column(Float, nullable=True)     # Model confidence 0–1
    final_decision  = Column(String(20), default="PENDING")  # PASS, REJECT, MARGINAL

    # Metadata
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    screened_at = Column(DateTime(timezone=True), nullable=True)

    lot_ref = relationship("Lot", back_populates="components")
    xai_results = relationship("XAIResult", back_populates="component_ref")


class AnalysisRun(Base):
    """Record of an analysis run (Module A, B, or both)"""
    __tablename__ = "analysis_runs"

    id = Column(Integer, primary_key=True, index=True)
    run_id = Column(String(50), unique=True, index=True)
    lot_id = Column(String(20), ForeignKey("lots.lot_id"), nullable=False)
    module = Column(String(10), nullable=False)          # A, B, FULL
    parameter = Column(String(20), nullable=True)
    z_threshold = Column(Float, default=3.0)
    iqr_multiplier = Column(Float, default=1.5)
    slope_multiplier = Column(Float, default=0.003)
    method = Column(String(30), default="ensemble")
    total_components = Column(Integer, default=0)
    flagged_count = Column(Integer, default=0)
    pass_count = Column(Integer, default=0)
    latent_defects_caught = Column(Integer, default=0)
    mae = Column(Float, nullable=True)
    r_squared = Column(Float, nullable=True)
    precision = Column(Float, nullable=True)
    recall = Column(Float, nullable=True)
    f1_score = Column(Float, nullable=True)
    status = Column(String(20), default="RUNNING")      # RUNNING, COMPLETE, ERROR
    started_at = Column(DateTime(timezone=True), server_default=func.now())
    completed_at = Column(DateTime(timezone=True), nullable=True)
    results_json = Column(JSON, nullable=True)

    lot_ref = relationship("Lot", back_populates="analysis_runs")


class XAIResult(Base):
    """SHAP explainability results per component"""
    __tablename__ = "xai_results"

    id = Column(Integer, primary_key=True, index=True)
    component_id = Column(String(50), ForeignKey("components.component_id"), nullable=False)
    run_id = Column(String(50), nullable=True)
    shap_values = Column(JSON, nullable=True)           # {feature: shap_value}
    feature_values = Column(JSON, nullable=True)        # {feature: actual_value}
    base_value = Column(Float, nullable=True)
    decision_reason = Column(Text, nullable=True)       # NLG justification
    top_feature = Column(String(100), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    component_ref = relationship("Component", back_populates="xai_results")


class SpacecraftTest(Base):
    """Spacecraft-specific parametric test definitions"""
    __tablename__ = "spacecraft_tests"

    id = Column(Integer, primary_key=True, index=True)
    test_code = Column(String(20), unique=True, nullable=False)   # e.g. "IDDQ", "TID"
    test_name = Column(String(100), nullable=False)
    category = Column(String(50), nullable=False)       # ELECTRICAL, TIMING, RADIATION, MECHANICAL
    unit = Column(String(20), nullable=False)
    typical_value = Column(Float, nullable=True)
    abs_max_limit = Column(Float, nullable=True)
    abs_min_limit = Column(Float, nullable=True)
    safety_slope_multiplier = Column(Float, default=0.003)
    standard = Column(String(50), nullable=True)        # MIL-STD-883, ECSS, etc.
    description = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True)
