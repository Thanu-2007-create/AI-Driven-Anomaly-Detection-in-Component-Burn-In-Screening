# ============================================================
#  ESS-AI BACKEND — api/routes.py
#  All REST API Route Definitions
# ============================================================
import uuid
import json
import io
import csv
from datetime import datetime
from typing import List, Optional, Dict, Any

import numpy as np
import pandas as pd
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Query, BackgroundTasks
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from database import get_db
import models
import schemas
from ml.data_gen import (
    generate_dataset, compute_lot_stats,
    get_test_catalog, SPACECRAFT_TESTS, LOT_IDS
)
from ml.outlier import DynamicOutlierDetector
from ml.drift import DriftPredictor
from ml.explainer import SHAPExplainer

router = APIRouter(prefix="/api", tags=["ESS-AI"])

# ─────────────────────────────────────────────
# HEALTH
# ─────────────────────────────────────────────
@router.get("/health")
def health():
    return {
        "status": "online",
        "version": "2.4.1",
        "timestamp": datetime.utcnow().isoformat(),
        "modules": ["Module-A-Outlier", "Module-B-Drift", "XAI-Engine"],
        "tests_catalog": len(SPACECRAFT_TESTS),
    }


# ─────────────────────────────────────────────
# SPACECRAFT TEST CATALOG
# ─────────────────────────────────────────────
@router.get("/tests", response_model=List[schemas.SpacecraftTestResponse])
def get_tests():
    """Return the full spacecraft test parameter catalog."""
    return get_test_catalog()


@router.get("/tests/{test_code}")
def get_test(test_code: str):
    spec = SPACECRAFT_TESTS.get(test_code.upper())
    if not spec:
        raise HTTPException(404, f"Test '{test_code}' not found in catalog")
    return {
        "test_code": test_code.upper(),
        **spec,
        "safety_slope_multiplier": spec["safety_slope_mult"],
    }


# ─────────────────────────────────────────────
# LOTS
# ─────────────────────────────────────────────
@router.get("/lots")
def list_lots(db: Session = Depends(get_db)):
    lots = db.query(models.Lot).all()
    result = []
    for lot in lots:
        total = db.query(models.Component).filter(models.Component.lot_id == lot.lot_id).count()
        anomalies = db.query(models.Component).filter(
            models.Component.lot_id == lot.lot_id,
            (models.Component.module_a_flag == True) | (models.Component.module_b_flag == True)
        ).count()
        pass_rate = ((total - anomalies) / max(total, 1)) * 100
        result.append({
            "id": lot.id,
            "lot_id": lot.lot_id,
            "description": lot.description,
            "device_type": lot.device_type,
            "technology_node": lot.technology_node,
            "burn_in_temp": lot.burn_in_temp,
            "burn_in_duration": lot.burn_in_duration,
            "created_at": lot.created_at.isoformat() if lot.created_at else None,
            "status": lot.status,
            "component_count": total,
            "anomaly_count": anomalies,
            "pass_rate": round(pass_rate, 2),
        })
    return result


@router.post("/lots", status_code=201)
def create_lot(lot: schemas.LotCreate, db: Session = Depends(get_db)):
    existing = db.query(models.Lot).filter(models.Lot.lot_id == lot.lot_id).first()
    if existing:
        raise HTTPException(409, f"Lot '{lot.lot_id}' already exists")
    db_lot = models.Lot(**lot.dict())
    db.add(db_lot)
    db.commit()
    db.refresh(db_lot)
    return {"message": f"Lot '{lot.lot_id}' created", "id": db_lot.id}


@router.get("/lots/{lot_id}/summary")
def lot_summary(lot_id: str, db: Session = Depends(get_db)):
    lot = db.query(models.Lot).filter(models.Lot.lot_id == lot_id).first()
    if not lot:
        raise HTTPException(404, f"Lot '{lot_id}' not found")
    comps = db.query(models.Component).filter(models.Component.lot_id == lot_id).all()
    if not comps:
        return {"lot_id": lot_id, "message": "No components found"}

    vals = [c.value_0h for c in comps if c.value_0h]
    anomaly_cnt = sum(1 for c in comps if c.module_a_flag or c.module_b_flag)
    drift_cnt = sum(1 for c in comps if c.module_b_flag)
    latent_cnt = sum(1 for c in comps if c.is_latent_defect)

    return {
        "lot_id": lot_id,
        "total_components": len(comps),
        "pass_count": len(comps) - anomaly_cnt,
        "reject_count": anomaly_cnt,
        "latent_defects": latent_cnt,
        "drift_flags": drift_cnt,
        "pass_rate": round((len(comps) - anomaly_cnt) / max(len(comps), 1) * 100, 2),
        "max_z_score": round(max((abs(c.z_score or 0) for c in comps), default=0), 3),
        "lot_mean_v0": round(np.mean(vals), 4) if vals else None,
        "lot_sigma_v0": round(np.std(vals), 4) if vals else None,
        "screening_complete": lot.status == "COMPLETE",
    }


# ─────────────────────────────────────────────
# COMPONENTS
# ─────────────────────────────────────────────
@router.get("/components")
def list_components(
    lot_id: Optional[str] = None,
    parameter: Optional[str] = None,
    decision: Optional[str] = None,
    limit: int = Query(100, le=1000),
    offset: int = 0,
    db: Session = Depends(get_db),
):
    q = db.query(models.Component)
    if lot_id and lot_id != "ALL":
        q = q.filter(models.Component.lot_id == lot_id)
    if parameter and parameter != "ALL":
        q = q.filter(models.Component.parameter == parameter)
    if decision:
        q = q.filter(models.Component.final_decision == decision)

    total = q.count()
    comps = q.offset(offset).limit(limit).all()

    return {
        "total": total,
        "offset": offset,
        "limit": limit,
        "components": [
            {
                "id": c.id,
                "component_id": c.component_id,
                "lot_id": c.lot_id,
                "parameter": c.parameter,
                "unit": c.unit,
                "value_0h": c.value_0h,
                "value_24h": c.value_24h,
                "value_96h": c.value_96h,
                "value_168h": c.value_168h,
                "lot_mean": c.lot_mean,
                "lot_sigma": c.lot_sigma,
                "z_score": c.z_score,
                "abs_limit_max": c.abs_limit_max,
                "module_a_flag": c.module_a_flag,
                "module_b_flag": c.module_b_flag,
                "is_hard_fail": c.is_hard_fail,
                "is_latent_defect": c.is_latent_defect,
                "anomaly_score": c.anomaly_score,
                "drift_rate": c.drift_rate,
                "pred_value_168h": c.pred_value_168h,
                "final_decision": c.final_decision,
                "confidence": c.confidence,
            }
            for c in comps
        ],
    }


@router.post("/components/upload", status_code=201)
async def upload_csv(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """Upload a CSV of component measurements for bulk ingest."""
    if not file.filename.endswith(".csv"):
        raise HTTPException(400, "Only CSV files are accepted")
    content = await file.read()
    try:
        df = pd.read_csv(io.StringIO(content.decode("utf-8")))
    except Exception as e:
        raise HTTPException(400, f"CSV parse error: {e}")

    required = ["component_id", "lot_id", "parameter", "value_0h"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise HTTPException(400, f"Missing required columns: {missing}")

    inserted = 0
    skipped = 0
    for _, row in df.iterrows():
        existing = db.query(models.Component).filter(
            models.Component.component_id == row["component_id"]
        ).first()
        if existing:
            skipped += 1
            continue

        # Ensure lot exists
        lot = db.query(models.Lot).filter(models.Lot.lot_id == row["lot_id"]).first()
        if not lot:
            db.add(models.Lot(lot_id=row["lot_id"], description="Auto-created from CSV upload"))
            db.commit()

        comp = models.Component(
            component_id=row["component_id"],
            lot_id=row["lot_id"],
            parameter=row["parameter"],
            unit=row.get("unit", "µA"),
            value_0h=float(row["value_0h"]),
            value_24h=float(row["value_24h"]) if "value_24h" in row and pd.notna(row["value_24h"]) else None,
            value_96h=float(row["value_96h"]) if "value_96h" in row and pd.notna(row["value_96h"]) else None,
            value_168h=float(row["value_168h"]) if "value_168h" in row and pd.notna(row["value_168h"]) else None,
            abs_limit_max=float(row["abs_limit_max"]) if "abs_limit_max" in row and pd.notna(row.get("abs_limit_max")) else None,
        )
        db.add(comp)
        inserted += 1

    db.commit()
    return {"inserted": inserted, "skipped": skipped, "filename": file.filename}


# ─────────────────────────────────────────────
# SIMULATION
# ─────────────────────────────────────────────
@router.post("/simulate")
def simulate_dataset(req: schemas.SimulateRequest, db: Session = Depends(get_db)):
    """Generate and load a synthetic ESS dataset into the database."""
    df = generate_dataset(
        n_lots=req.n_lots,
        components_per_lot_param=req.components_per_lot_param,
        latent_defect_rate=req.latent_defect_rate,
        hard_fail_rate=req.hard_fail_rate,
        parameters=req.parameters,
        seed=int(datetime.utcnow().timestamp()) % 10000,
    )
    df = compute_lot_stats(df)

    inserted = 0
    for _, row in df.iterrows():
        # Ensure lot exists
        if not db.query(models.Lot).filter(models.Lot.lot_id == row["lot_id"]).first():
            db.add(models.Lot(
                lot_id=row["lot_id"],
                description=f"Simulated lot — {row['lot_id']}",
                device_type="ASIC-SpaceSoC",
                technology_node="28nm CMOS",
                burn_in_temp=125.0,
                burn_in_duration=168.0,
            ))
            db.commit()

        # Skip duplicates
        if db.query(models.Component).filter(
            models.Component.component_id == row["component_id"]
        ).first():
            continue

        comp = models.Component(
            component_id=row["component_id"],
            lot_id=row["lot_id"],
            parameter=row["parameter"],
            unit=row.get("unit", "µA"),
            value_0h=float(row["value_0h"]),
            value_24h=float(row["value_24h"]),
            value_96h=float(row["value_96h"]),
            value_168h=float(row["value_168h"]),
            lot_mean=float(row.get("lot_mean", row["value_0h"])),
            lot_sigma=float(row.get("lot_sigma", 1.0)),
            z_score=float(row.get("z_score", 0)),
            abs_limit_max=float(row.get("abs_limit_max", 9999)),
            abs_limit_min=float(row.get("abs_limit_min", -9999)),
        )
        db.add(comp)
        inserted += 1

    db.commit()
    return {
        "message": "Simulation complete",
        "components_generated": len(df),
        "inserted_to_db": inserted,
        "lots": req.n_lots,
        "parameters": req.parameters,
    }


# ─────────────────────────────────────────────
# ANALYSIS — MODULE A: OUTLIER DETECTION
# ─────────────────────────────────────────────
@router.post("/analyze/outlier")
def run_outlier_analysis(req: schemas.OutlierAnalysisRequest, db: Session = Depends(get_db)):
    """Run Module A — Dynamic Outlier Detection on the specified lot/parameter."""
    q = db.query(models.Component)
    if req.lot_id and req.lot_id != "ALL":
        q = q.filter(models.Component.lot_id == req.lot_id)
    if req.parameter and req.parameter != "ALL":
        q = q.filter(models.Component.parameter == req.parameter)

    comps = q.all()
    if not comps:
        raise HTTPException(404, "No components found matching the filter criteria")

    df = pd.DataFrame([{
        "component_id": c.component_id,
        "lot_id": c.lot_id,
        "parameter": c.parameter,
        "value_0h": c.value_0h or 0,
        "value_24h": c.value_24h,
        "value_96h": c.value_96h,
        "value_168h": c.value_168h,
        "lot_mean": c.lot_mean or 0,
        "lot_sigma": c.lot_sigma or 1,
        "abs_limit_max": c.abs_limit_max or 9999,
        "abs_limit_min": c.abs_limit_min or -9999,
        "is_hard_fail_gt": c.is_hard_fail,
        "is_latent_gt": c.is_latent_defect,
    } for c in comps])

    detector = DynamicOutlierDetector(
        z_threshold=req.z_threshold,
        iqr_multiplier=req.iqr_multiplier,
        contamination=req.contamination,
        method=req.method,
    )

    result = detector.analyze(df, time_point=req.time_point)

    # Persist decisions back to DB
    for comp_result in result["components"]:
        db_comp = db.query(models.Component).filter(
            models.Component.component_id == comp_result["component_id"]
        ).first()
        if db_comp:
            db_comp.module_a_flag = comp_result["ensemble_flag"]
            db_comp.is_hard_fail = comp_result["is_hard_fail"]
            db_comp.is_latent_defect = comp_result["is_latent"]
            db_comp.z_score = comp_result["z_score"]
            db_comp.anomaly_score = comp_result["anomaly_score"]
            db_comp.final_decision = comp_result["final_decision"]
            db_comp.confidence = comp_result["confidence"]
            db_comp.screened_at = datetime.utcnow()
    db.commit()

    return result


# ─────────────────────────────────────────────
# ANALYSIS — MODULE B: DRIFT PREDICTION
# ─────────────────────────────────────────────
@router.post("/analyze/drift")
def run_drift_analysis(req: schemas.DriftAnalysisRequest, db: Session = Depends(get_db)):
    """Run Module B — Time-Series Drift Prediction."""
    q = db.query(models.Component)
    if req.lot_id and req.lot_id != "ALL":
        q = q.filter(models.Component.lot_id == req.lot_id)
    if req.parameter and req.parameter != "ALL":
        q = q.filter(models.Component.parameter == req.parameter)

    comps = q.all()
    if not comps:
        raise HTTPException(404, "No components found")

    df = pd.DataFrame([{
        "component_id": c.component_id,
        "lot_id": c.lot_id,
        "parameter": c.parameter,
        "value_0h": c.value_0h or 0,
        "value_24h": c.value_24h or c.value_0h or 0,
        "value_96h": c.value_96h,
        "value_168h": c.value_168h,
        "lot_mean": c.lot_mean or 0,
        "lot_sigma": c.lot_sigma or 1,
    } for c in comps])

    predictor = DriftPredictor(
        slope_multiplier=req.slope_multiplier,
        model_type=req.model_type,
        degree=req.degree,
    )

    result = predictor.analyze(df)

    # Persist drift results
    for comp_result in result["components"]:
        db_comp = db.query(models.Component).filter(
            models.Component.component_id == comp_result["component_id"]
        ).first()
        if db_comp:
            db_comp.module_b_flag = comp_result["drift_flag"]
            db_comp.drift_rate = comp_result["drift_rate"]
            db_comp.pred_value_168h = comp_result["pred_value_168h"]
            if comp_result["drift_flag"]:
                db_comp.final_decision = "REJECT"
    db.commit()

    return result


# ─────────────────────────────────────────────
# ANALYSIS — FULL PIPELINE
# ─────────────────────────────────────────────
@router.post("/analyze/full")
def run_full_analysis(req: schemas.FullAnalysisRequest, db: Session = Depends(get_db)):
    """Run the complete Module A + Module B pipeline."""
    outlier_req = schemas.OutlierAnalysisRequest(
        lot_id=req.lot_id,
        parameter=req.parameter if req.parameter != "ALL" else "IDDQ",
        z_threshold=req.z_threshold,
        iqr_multiplier=req.iqr_multiplier,
        method=req.method,
    )
    drift_req = schemas.DriftAnalysisRequest(
        lot_id=req.lot_id,
        parameter=req.parameter if req.parameter != "ALL" else "IDDQ",
        slope_multiplier=req.slope_multiplier,
        model_type=req.model_type,
    )

    outlier_result = run_outlier_analysis(outlier_req, db)
    drift_result = run_drift_analysis(drift_req, db)

    # Merge decisions
    total = outlier_result["total"]
    combined_flags = set()
    for c in outlier_result["components"]:
        if c["ensemble_flag"] or c["is_hard_fail"]:
            combined_flags.add(c["component_id"])
    for c in drift_result["components"]:
        if c["drift_flag"]:
            combined_flags.add(c["component_id"])

    pass_count = total - len(combined_flags)
    latent = outlier_result.get("latent_defects_caught", 0)

    return {
        "run_id": f"FULL-{uuid.uuid4().hex[:8].upper()}",
        "outlier": outlier_result,
        "drift": drift_result,
        "combined_flags": len(combined_flags),
        "total_components": total,
        "pass_count": pass_count,
        "reject_count": len(combined_flags),
        "latent_defects": latent,
        "pass_rate": round(pass_count / max(total, 1) * 100, 2),
        "summary": {
            "module_a_flags": outlier_result["flagged"],
            "module_b_flags": drift_result["drift_flags"],
            "combined_unique_flags": len(combined_flags),
            "mae": drift_result.get("mae"),
            "r2": drift_result.get("r_squared"),
            "precision": outlier_result.get("precision"),
            "recall": outlier_result.get("recall"),
        },
    }


# ─────────────────────────────────────────────
# XAI — EXPLAINABILITY
# ─────────────────────────────────────────────
@router.get("/xai/component/{component_id}")
def xai_component(component_id: str, db: Session = Depends(get_db)):
    """Get SHAP explanation for a single component."""
    comp = db.query(models.Component).filter(
        models.Component.component_id == component_id
    ).first()
    if not comp:
        raise HTTPException(404, f"Component '{component_id}' not found")

    comp_dict = {
        "component_id": comp.component_id,
        "lot_id": comp.lot_id,
        "parameter": comp.parameter,
        "value_0h": comp.value_0h or 0,
        "value_24h": comp.value_24h or comp.value_0h or 0,
        "value_96h": comp.value_96h,
        "value_168h": comp.value_168h,
        "z_score": comp.z_score or 0,
        "iqr_flag": False,
        "isoforest_flag": comp.module_a_flag,
        "lof_flag": comp.module_a_flag,
        "drift_flag": comp.module_b_flag,
        "drift_rate": comp.drift_rate or 0,
        "pred_value_168h": comp.pred_value_168h,
        "final_decision": comp.final_decision or "PENDING",
        "anomaly_score": comp.anomaly_score or 0,
        "confidence": comp.confidence or 0.5,
        "abs_limit_max": comp.abs_limit_max,
    }

    lot_mean = comp.lot_mean or comp.value_0h or 10.0
    lot_sigma = comp.lot_sigma or 1.5
    spec = SPACECRAFT_TESTS.get(comp.parameter, {})
    safety_slope = lot_mean * abs(spec.get("safety_slope_mult", 0.003))

    explainer = SHAPExplainer()
    result = explainer.explain_component(
        comp_dict,
        lot_mean=lot_mean,
        lot_sigma=lot_sigma,
        iqr_upper=lot_mean + 3 * lot_sigma,
        safety_slope=safety_slope,
        param=comp.parameter,
    )
    return result


@router.post("/xai/batch")
def xai_batch(lot_id: str, parameter: str = "IDDQ", db: Session = Depends(get_db)):
    """Run XAI on all flagged components in a lot."""
    q = db.query(models.Component).filter(
        models.Component.lot_id == lot_id,
        models.Component.parameter == parameter,
    )
    comps = q.all()
    if not comps:
        raise HTTPException(404, "No components found")

    comp_dicts = [{
        "component_id": c.component_id,
        "lot_id": c.lot_id,
        "parameter": c.parameter,
        "value_0h": c.value_0h or 0,
        "value_24h": c.value_24h or c.value_0h or 0,
        "z_score": c.z_score or 0,
        "iqr_flag": False,
        "isoforest_flag": c.module_a_flag or False,
        "lof_flag": c.module_a_flag or False,
        "drift_flag": c.module_b_flag or False,
        "drift_rate": c.drift_rate or 0,
        "pred_value_168h": c.pred_value_168h,
        "final_decision": c.final_decision or "PENDING",
        "anomaly_score": c.anomaly_score or 0,
        "confidence": c.confidence or 0.5,
        "abs_limit_max": c.abs_limit_max,
    } for c in comps]

    means = [c.lot_mean for c in comps if c.lot_mean]
    lot_mean = float(np.mean(means)) if means else 10.0
    lot_sigma = float(np.std(means)) if len(means) > 1 else 1.5
    spec = SPACECRAFT_TESTS.get(parameter, {})
    safety_slope = lot_mean * abs(spec.get("safety_slope_mult", 0.003))

    explainer = SHAPExplainer()
    return explainer.explain_batch(
        comp_dicts, lot_mean, lot_sigma, lot_mean + 3 * lot_sigma, safety_slope, parameter
    )


# ─────────────────────────────────────────────
# REPORTS
# ─────────────────────────────────────────────
@router.get("/reports/summary")
def report_summary(db: Session = Depends(get_db)):
    """Master screening summary across all lots."""
    all_comps = db.query(models.Component).all()
    if not all_comps:
        return {"message": "No data available. Run simulation first.", "total": 0}

    total = len(all_comps)
    passed = sum(1 for c in all_comps if c.final_decision == "PASS")
    rejected = sum(1 for c in all_comps if c.final_decision == "REJECT")
    latent = sum(1 for c in all_comps if c.is_latent_defect)
    drift = sum(1 for c in all_comps if c.module_b_flag)

    lot_ids = list(set(c.lot_id for c in all_comps))
    lot_summaries = []
    for lot_id in lot_ids:
        lc = [c for c in all_comps if c.lot_id == lot_id]
        la = sum(1 for c in lc if c.module_a_flag or c.module_b_flag)
        lot_summaries.append({
            "lot_id": lot_id,
            "total": len(lc),
            "passed": len(lc) - la,
            "rejected": la,
            "pass_rate": round((len(lc) - la) / max(len(lc), 1) * 100, 2),
        })

    return {
        "report_id": f"RPT-{uuid.uuid4().hex[:8].upper()}",
        "generated_at": datetime.utcnow().isoformat(),
        "total_components": total,
        "total_passed": passed,
        "total_rejected": rejected,
        "total_latent_caught": latent,
        "total_drift_flags": drift,
        "overall_pass_rate": round(passed / max(total, 1) * 100, 2),
        "lot_summaries": lot_summaries,
        "parameters_tested": list(set(c.parameter for c in all_comps)),
    }


@router.get("/reports/export")
def export_csv(
    lot_id: Optional[str] = None,
    parameter: Optional[str] = None,
    db: Session = Depends(get_db),
):
    """Export screening results as CSV."""
    q = db.query(models.Component)
    if lot_id and lot_id != "ALL":
        q = q.filter(models.Component.lot_id == lot_id)
    if parameter and parameter != "ALL":
        q = q.filter(models.Component.parameter == parameter)
    comps = q.all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "component_id", "lot_id", "parameter", "unit",
        "value_0h", "value_24h", "value_96h", "value_168h",
        "lot_mean", "lot_sigma", "z_score", "abs_limit_max",
        "module_a_flag", "module_b_flag", "is_hard_fail", "is_latent_defect",
        "anomaly_score", "drift_rate", "pred_value_168h", "final_decision", "confidence",
    ])
    for c in comps:
        writer.writerow([
            c.component_id, c.lot_id, c.parameter, c.unit,
            c.value_0h, c.value_24h, c.value_96h, c.value_168h,
            c.lot_mean, c.lot_sigma, c.z_score, c.abs_limit_max,
            c.module_a_flag, c.module_b_flag, c.is_hard_fail, c.is_latent_defect,
            c.anomaly_score, c.drift_rate, c.pred_value_168h, c.final_decision, c.confidence,
        ])

    output.seek(0)
    filename = f"ess_ai_export_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv"
    return StreamingResponse(
        io.BytesIO(output.read().encode("utf-8")),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


@router.get("/reports/lot/{lot_id}/pdf-data")
def lot_pdf_data(lot_id: str, db: Session = Depends(get_db)):
    """Return structured data for client-side PDF generation."""
    comps = db.query(models.Component).filter(models.Component.lot_id == lot_id).all()
    if not comps:
        raise HTTPException(404, "No components for this lot")

    by_param = {}
    for c in comps:
        by_param.setdefault(c.parameter, []).append(c)

    param_stats = {}
    for param, pcomps in by_param.items():
        vals = [c.value_0h for c in pcomps if c.value_0h is not None]
        param_stats[param] = {
            "count": len(pcomps),
            "mean": round(np.mean(vals), 4) if vals else None,
            "std": round(np.std(vals), 4) if vals else None,
            "anomaly_count": sum(1 for c in pcomps if c.module_a_flag or c.module_b_flag),
        }

    return {
        "lot_id": lot_id,
        "total_components": len(comps),
        "param_stats": param_stats,
        "anomalies": [
            {
                "component_id": c.component_id,
                "parameter": c.parameter,
                "value_0h": c.value_0h,
                "z_score": c.z_score,
                "final_decision": c.final_decision,
            }
            for c in comps if c.module_a_flag or c.module_b_flag
        ][:50],
    }


# ─────────────────────────────────────────────
# STATISTICS / CHARTS DATA
# ─────────────────────────────────────────────
@router.get("/stats/drift-profile/{lot_id}/{parameter}")
def drift_profile(lot_id: str, parameter: str, limit: int = 30, db: Session = Depends(get_db)):
    """Return time-series drift data for chart rendering."""
    comps = db.query(models.Component).filter(
        models.Component.lot_id == lot_id,
        models.Component.parameter == parameter,
    ).limit(limit).all()

    return {
        "lot_id": lot_id,
        "parameter": parameter,
        "components": [
            {
                "id": c.component_id,
                "v0": c.value_0h,
                "v24": c.value_24h,
                "v96": c.value_96h,
                "v168": c.value_168h,
                "is_anomaly": c.module_a_flag or c.module_b_flag,
                "decision": c.final_decision,
            }
            for c in comps
        ],
    }


@router.get("/stats/heatmap")
def anomaly_heatmap(db: Session = Depends(get_db)):
    """Return lot × parameter anomaly rate matrix for heatmap rendering."""
    comps = db.query(models.Component).all()
    if not comps:
        return {"data": []}

    from collections import defaultdict
    grid = defaultdict(lambda: {"total": 0, "anomaly": 0})
    for c in comps:
        key = (c.lot_id, c.parameter)
        grid[key]["total"] += 1
        if c.module_a_flag or c.module_b_flag:
            grid[key]["anomaly"] += 1

    result = []
    for (lot, param), counts in grid.items():
        result.append({
            "lot_id": lot,
            "parameter": param,
            "total": counts["total"],
            "anomaly": counts["anomaly"],
            "rate": round(counts["anomaly"] / max(counts["total"], 1) * 100, 2),
        })

    return {"data": result}
