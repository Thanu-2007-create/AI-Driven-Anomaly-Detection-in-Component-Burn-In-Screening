// ============================================================
//  SPACE ESS ANALYZER — SHARED JAVASCRIPT (shared.js)
// ============================================================

/* ─── SPACE PARTICLE BACKGROUND ─── */
function initSpaceCanvas() {
  const canvas = document.getElementById('space-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let W = (canvas.width = window.innerWidth);
  let H = (canvas.height = window.innerHeight);

  const STARS = Array.from({ length: 180 }, () => ({
    x: Math.random() * W,
    y: Math.random() * H,
    r: Math.random() * 1.4 + 0.2,
    speed: Math.random() * 0.3 + 0.05,
    opacity: Math.random() * 0.7 + 0.1,
    twinkle: Math.random() * Math.PI * 2,
  }));

  const NEBULAE = Array.from({ length: 3 }, () => ({
    x: Math.random() * W,
    y: Math.random() * H,
    r: Math.random() * 300 + 150,
    hue: [200, 260, 190][Math.floor(Math.random() * 3)],
    opacity: Math.random() * 0.04 + 0.01,
  }));

  let frame = 0;

  function draw() {
    ctx.clearRect(0, 0, W, H);

    // Nebulae
    NEBULAE.forEach(n => {
      const grad = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, n.r);
      grad.addColorStop(0, `hsla(${n.hue},80%,60%,${n.opacity})`);
      grad.addColorStop(1, 'transparent');
      ctx.beginPath();
      ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
      ctx.fillStyle = grad;
      ctx.fill();
    });

    // Stars
    frame++;
    STARS.forEach(s => {
      s.twinkle += 0.02;
      const twinkleOp = s.opacity * (0.7 + 0.3 * Math.sin(s.twinkle));
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(200, 230, 255, ${twinkleOp})`;
      ctx.fill();
    });

    requestAnimationFrame(draw);
  }

  draw();

  window.addEventListener('resize', () => {
    W = canvas.width = window.innerWidth;
    H = canvas.height = window.innerHeight;
  });
}

/* ─── LIVE CLOCK ─── */
function initClock() {
  const el = document.getElementById('nav-clock');
  if (!el) return;
  const update = () => {
    const now = new Date();
    const hh = String(now.getHours()).padStart(2, '0');
    const mm = String(now.getMinutes()).padStart(2, '0');
    const ss = String(now.getSeconds()).padStart(2, '0');
    el.textContent = `${hh}:${mm}:${ss} UTC`;
  };
  update();
  setInterval(update, 1000);
}

/* ─── ACTIVE NAV LINK ─── */
function setActiveNav() {
  const path = window.location.pathname;
  document.querySelectorAll('.nav-link').forEach(link => {
    link.classList.remove('active');
    if (link.getAttribute('href') && path.includes(link.getAttribute('href').replace('.html', '').replace('./', ''))) {
      link.classList.add('active');
    }
  });
  // Home special case
  if (path.endsWith('/') || path.endsWith('index.html')) {
    document.querySelectorAll('.nav-link[href="index.html"]').forEach(l => l.classList.add('active'));
  }
}

/* ─── TAB SYSTEM ─── */
function initTabs(containerSelector) {
  const containers = document.querySelectorAll(containerSelector || '.tab-container');
  containers.forEach(container => {
    const btns = container.querySelectorAll('.tab-btn');
    const contents = container.querySelectorAll('.tab-content');
    btns.forEach((btn, i) => {
      btn.addEventListener('click', () => {
        btns.forEach(b => b.classList.remove('active'));
        contents.forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
        contents[i]?.classList.add('active');
      });
    });
  });
}

/* ─── ANIMATED COUNTER ─── */
function animateCounter(el, target, duration = 1500, decimals = 0, prefix = '', suffix = '') {
  const start = parseFloat(el.dataset.from || 0);
  const startTime = performance.now();
  function step(now) {
    const progress = Math.min((now - startTime) / duration, 1);
    const ease = 1 - Math.pow(1 - progress, 3);
    const value = start + (target - start) * ease;
    el.textContent = prefix + value.toFixed(decimals) + suffix;
    if (progress < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

/* ─── INTERSECT ANIMATION ─── */
function initIntersectAnimations() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('fade-in');
        observer.unobserve(entry.target);
        // Animate counters
        entry.target.querySelectorAll('[data-counter]').forEach(el => {
          animateCounter(el, parseFloat(el.dataset.counter), 1500,
            parseInt(el.dataset.decimals || 0),
            el.dataset.prefix || '',
            el.dataset.suffix || '');
        });
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.animate-on-scroll').forEach(el => observer.observe(el));
}

/* ─── DATA GENERATION HELPERS ─── */
const ESS_DATA = (function () {
  const LOT_IDS = ['LOT-A77', 'LOT-B12', 'LOT-C34', 'LOT-D91', 'LOT-E55', 'LOT-F03'];
  const PARAM_TYPES = ['IDDQ', 'ILEAK', 'TPROP', 'VTH_N', 'VTH_P'];

  function normalRandom(mean, std) {
    const u = 1 - Math.random();
    const v = Math.random();
    return mean + std * Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }

  function generateComponent(id, lotId, paramType, isLatentDefect = false, isHardFail = false) {
    const base = { IDDQ: 10, ILEAK: 8, TPROP: 5.2, VTH_N: 0.45, VTH_P: -0.42 }[paramType];
    const sigma = { IDDQ: 1.5, ILEAK: 1.2, TPROP: 0.3, VTH_N: 0.02, VTH_P: 0.02 }[paramType];
    const limit = { IDDQ: 50, ILEAK: 40, TPROP: 8.0, VTH_N: 0.6, VTH_P: -0.28 }[paramType];

    let v0 = normalRandom(base, sigma);
    let v24, v96, v168;

    if (isHardFail) {
      v0 = normalRandom(limit * 1.1, sigma * 2);
      v24 = v0 * normalRandom(1.05, 0.02);
      v96 = v24 * normalRandom(1.08, 0.02);
      v168 = v96 * normalRandom(1.1, 0.02);
    } else if (isLatentDefect) {
      v0 = normalRandom(base * normalRandom(3.5, 0.5), sigma * 1.5);
      v24 = v0 * normalRandom(1.08, 0.03);
      v96 = v24 * normalRandom(1.12, 0.04);
      v168 = v96 * normalRandom(1.15, 0.05);
    } else {
      v24 = v0 * normalRandom(1.005, 0.01);
      v96 = v24 * normalRandom(1.008, 0.01);
      v168 = v96 * normalRandom(1.01, 0.01);
    }

    const lotMean = base;
    const driftRate = (v168 - v0) / 168;
    const safeSlopeLimit = base * 0.003;

    return {
      id: `${lotId}-${paramType}-${String(id).padStart(4, '0')}`,
      lot: lotId,
      param: paramType,
      v0: +v0.toFixed(4),
      v24: +v24.toFixed(4),
      v96: +v96.toFixed(4),
      v168: +v168.toFixed(4),
      lotMean: +lotMean.toFixed(4),
      lotSigma: +sigma.toFixed(4),
      absoluteLimit: limit,
      driftRate: +driftRate.toFixed(6),
      safeSlopeLimit: +safeSlopeLimit.toFixed(6),
      isHardFail: isHardFail || v0 > limit,
      isLatentDefect: !isHardFail && isLatentDefect,
      zScore: +((v0 - base) / sigma).toFixed(3),
      driftFlagB: driftRate > safeSlopeLimit,
    };
  }

  function generateDataset(n = 120) {
    const data = [];
    let id = 1;
    LOT_IDS.forEach(lot => {
      PARAM_TYPES.forEach(param => {
        const count = Math.floor(n / (LOT_IDS.length * PARAM_TYPES.length));
        for (let i = 0; i < count; i++) {
          const rnd = Math.random();
          const isLatent = rnd > 0.94 && rnd <= 0.98;
          const isHard = rnd > 0.98;
          data.push(generateComponent(id++, lot, param, isLatent, isHard));
        }
      });
    });
    return data;
  }

  return { generateDataset, LOT_IDS, PARAM_TYPES, normalRandom };
})();

/* ─── FORMAT HELPERS ─── */
function fmtVal(v, decimals = 3) { return typeof v === 'number' ? v.toFixed(decimals) : v; }
function fmtUnit(param) {
  return { IDDQ: 'µA', ILEAK: 'µA', TPROP: 'ns', VTH_N: 'V', VTH_P: 'V' }[param] || '';
}

/* ─── NOTIFICATION TOAST ─── */
function showToast(message, type = 'info', duration = 3500) {
  const colors = { info: 'var(--primary)', danger: 'var(--danger)', success: 'var(--success)', warning: 'var(--warning)' };
  const icons = { info: 'ℹ️', danger: '🚨', success: '✅', warning: '⚠️' };
  const toast = document.createElement('div');
  toast.style.cssText = `
    position:fixed; bottom:24px; right:24px; z-index:9999;
    background:var(--bg-card2); border:1px solid ${colors[type]};
    border-radius:10px; padding:14px 20px;
    display:flex; align-items:center; gap:12px;
    font-family:var(--font-body); font-size:14px; color:var(--text-primary);
    box-shadow:0 8px 30px rgba(0,0,0,0.5);
    animation: toastIn 0.4s ease;
    max-width: 360px;
  `;
  toast.innerHTML = `<span>${icons[type]}</span><span>${message}</span>`;
  const style = document.createElement('style');
  style.textContent = `@keyframes toastIn{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}`;
  document.head.appendChild(style);
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

/* ─── INIT ALL ─── */
document.addEventListener('DOMContentLoaded', () => {
  initSpaceCanvas();
  initClock();
  setActiveNav();
  initTabs();
  initIntersectAnimations();
});
