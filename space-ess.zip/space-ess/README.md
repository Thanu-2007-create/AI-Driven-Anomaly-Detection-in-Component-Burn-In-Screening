# ESS-AI — SpaceOScan Reliability Platform
## AI-Driven Anomaly Detection for Component Burn-In & Screening

> **How to Run in 2 Steps**

### Step 1 — Start Backend
```
double-click: backend/start_server.bat
```
Or:
```bash
cd backend
python start_server.py
```

### Step 2 — Open Frontend
Open `frontend/index.html` in your browser.

The frontend works **without the backend** too (uses demo data automatically).

---

## What's Inside

```
space-ess/
├── backend/                 ← Python FastAPI + ML Engine
│   ├── main.py              ← Server entry point
│   ├── models.py            ← Database tables
│   ├── schemas.py           ← API validation
│   ├── ml/
│   │   ├── data_gen.py      ← 15-parameter ESS dataset generator
│   │   ├── outlier.py       ← Module A: Z-Score+IQR+IsoForest+LOF
│   │   ├── drift.py         ← Module B: GBR+Poly+Ridge prediction
│   │   └── explainer.py     ← SHAP + NLG justifications
│   ├── api/routes.py        ← 20+ REST endpoints
│   ├── requirements.txt
│   └── start_server.bat     ← Windows launcher
│
└── frontend/                ← 8 HTML Pages
    ├── index.html           ← Mission landing
    ├── dashboard.html       ← Live mission control
    ├── module-a.html        ← Outlier detection
    ├── module-b.html        ← Drift prediction
    ├── explainability.html  ← XAI + SHAP
    ├── reports.html         ← QA reports
    ├── data-upload.html     ← CSV upload + simulation
    ├── tests.html           ← All 15 spacecraft tests
    ├── css/main.css
    └── js/
        ├── shared.js        ← Canvas, clock, tabs
        ├── api.js           ← Backend API client
        └── ws.js            ← Live WebSocket feed
```

## API Docs
Once server is running: http://localhost:8000/docs
