// ============================================================
//  ESS-AI FRONTEND — js/api.js
//  API Client for Backend Communication
// ============================================================

const API_BASE = 'http://localhost:8000/api';

class ESSApiClient {
  constructor(base = API_BASE) {
    this.base = base;
    this.online = false;
    this._checkOnline();
  }

  async _checkOnline() {
    try {
      const r = await fetch(`${this.base}/health`, { signal: AbortSignal.timeout(3000) });
      this.online = r.ok;
      if (this.online) {
        const d = await r.json();
        console.log(`[ESS-AI] Backend online v${d.version}`);
        document.querySelectorAll('.api-status').forEach(el => {
          el.textContent = '🟢 API ONLINE';
          el.style.color = 'var(--success)';
        });
      }
    } catch {
      this.online = false;
      console.warn('[ESS-AI] Backend offline — using demo data');
      document.querySelectorAll('.api-status').forEach(el => {
        el.textContent = '🔴 DEMO MODE';
        el.style.color = 'var(--warning)';
      });
    }
  }

  async get(path, params = {}) {
    const url = new URL(`${this.base}${path}`);
    Object.entries(params).forEach(([k, v]) => v !== undefined && url.searchParams.set(k, v));
    const r = await fetch(url.toString(), { signal: AbortSignal.timeout(10000) });
    if (!r.ok) throw new Error(`API ${r.status}: ${r.statusText}`);
    return r.json();
  }

  async post(path, body = {}) {
    const r = await fetch(`${this.base}${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(30000),
    });
    if (!r.ok) {
      const err = await r.json().catch(() => ({}));
      throw new Error(err.detail || `API ${r.status}`);
    }
    return r.json();
  }

  async postForm(path, formData) {
    const r = await fetch(`${this.base}${path}`, {
      method: 'POST',
      body: formData,
      signal: AbortSignal.timeout(30000),
    });
    if (!r.ok) throw new Error(`Upload failed: ${r.status}`);
    return r.json();
  }

  // ─── Typed API Methods ───

  async health()           { return this.get('/health'); }
  async getTests()         { return this.get('/tests'); }
  async getLots()          { return this.get('/lots'); }
  async getLotSummary(id)  { return this.get(`/lots/${id}/summary`); }

  async getComponents(filters = {}) {
    return this.get('/components', filters);
  }

  async simulate(opts = {}) {
    return this.post('/simulate', {
      n_lots: opts.n_lots || 6,
      components_per_lot_param: opts.per_lot || 40,
      latent_defect_rate: opts.latent_rate || 0.04,
      hard_fail_rate: opts.hard_rate || 0.02,
      parameters: opts.parameters || ["IDDQ","ILEAK","TPROP","VTH_N","VTH_P"],
    });
  }

  async runOutlierAnalysis(opts = {}) {
    return this.post('/analyze/outlier', {
      lot_id: opts.lot_id || 'ALL',
      parameter: opts.parameter || 'IDDQ',
      time_point: opts.time_point || 'value_0h',
      z_threshold: opts.z_threshold || 3.0,
      iqr_multiplier: opts.iqr_multiplier || 1.5,
      method: opts.method || 'ensemble',
      contamination: opts.contamination || 0.05,
    });
  }

  async runDriftAnalysis(opts = {}) {
    return this.post('/analyze/drift', {
      lot_id: opts.lot_id || 'ALL',
      parameter: opts.parameter || 'IDDQ',
      slope_multiplier: opts.slope_multiplier || 0.003,
      model_type: opts.model_type || 'ensemble',
      degree: opts.degree || 3,
    });
  }

  async runFullAnalysis(opts = {}) {
    return this.post('/analyze/full', {
      lot_id: opts.lot_id || 'ALL',
      parameter: opts.parameter || 'IDDQ',
      z_threshold: opts.z_threshold || 3.0,
      iqr_multiplier: opts.iqr_multiplier || 1.5,
      slope_multiplier: opts.slope_multiplier || 0.003,
      method: opts.method || 'ensemble',
      model_type: opts.model_type || 'ensemble',
    });
  }

  async getXAI(componentId)      { return this.get(`/xai/component/${componentId}`); }
  async runXAIBatch(lotId, param) { return this.post(`/xai/batch?lot_id=${lotId}&parameter=${param}`); }
  async getSummaryReport()        { return this.get('/reports/summary'); }
  async getHeatmap()              { return this.get('/stats/heatmap'); }
  async getDriftProfile(lot, param, limit = 30) {
    return this.get(`/stats/drift-profile/${lot}/${param}`, { limit });
  }
  async exportCSV(lot_id, parameter) {
    const params = new URLSearchParams({ lot_id: lot_id || '', parameter: parameter || '' });
    const url = `${this.base}/reports/export?${params}`;
    window.open(url, '_blank');
  }
}

// Global singleton
const api = new ESSApiClient();

// ─── DEMO DATA FALLBACKS ───
const DEMO = {
  tests: [
    { test_code:'IDDQ', test_name:'Quiescent Standby Current', category:'ELECTRICAL', unit:'µA', typical_value:10.0, abs_max_limit:50.0, abs_min_limit:0.0, safety_slope_multiplier:0.003, standard:'MIL-STD-883K Method 1015', description:'Static CMOS standby current indicating gate oxide integrity.' },
    { test_code:'ILEAK', test_name:'Gate/Junction Leakage Current', category:'ELECTRICAL', unit:'µA', typical_value:8.0, abs_max_limit:40.0, abs_min_limit:0.0, safety_slope_multiplier:0.003, standard:'MIL-STD-883K Method 1015', description:'Reverse-biased junction leakage under thermal stress.' },
    { test_code:'TPROP', test_name:'Propagation Delay', category:'TIMING', unit:'ns', typical_value:5.2, abs_max_limit:8.0, abs_min_limit:0.0, safety_slope_multiplier:0.002, standard:'JEDEC JESD22-A108', description:'Gate propagation delay under thermal stress.' },
    { test_code:'VTH_N', test_name:'NMOS Threshold Voltage', category:'ELECTRICAL', unit:'V', typical_value:0.45, abs_max_limit:0.65, abs_min_limit:0.25, safety_slope_multiplier:0.001, standard:'ECSS-Q-ST-60C', description:'NMOS threshold voltage shift (NBTI indicator).' },
    { test_code:'VTH_P', test_name:'PMOS Threshold Voltage', category:'ELECTRICAL', unit:'V', typical_value:-0.42, abs_max_limit:-0.28, abs_min_limit:-0.65, safety_slope_multiplier:0.001, standard:'ECSS-Q-ST-60C', description:'PMOS threshold voltage (PBTI indicator).' },
    { test_code:'ICC', test_name:'Active Supply Current', category:'ELECTRICAL', unit:'mA', typical_value:15.0, abs_max_limit:35.0, abs_min_limit:5.0, safety_slope_multiplier:0.004, standard:'MIL-STD-883K', description:'Electromigration indicator.' },
    { test_code:'VOUT', test_name:'Output Voltage Swing', category:'ELECTRICAL', unit:'V', typical_value:3.28, abs_max_limit:3.6, abs_min_limit:3.0, safety_slope_multiplier:0.0005, standard:'MIL-STD-883K', description:'Output drive strength degradation monitor.' },
    { test_code:'CMRR', test_name:'Common-Mode Rejection Ratio', category:'ELECTRICAL', unit:'dB', typical_value:90.0, abs_max_limit:120.0, abs_min_limit:60.0, safety_slope_multiplier:-0.002, standard:'ECSS-Q-ST-60C', description:'Aging degrades noise immunity.' },
    { test_code:'PSRR', test_name:'Power Supply Rejection Ratio', category:'ELECTRICAL', unit:'dB', typical_value:85.0, abs_max_limit:120.0, abs_min_limit:55.0, safety_slope_multiplier:-0.002, standard:'MIL-STD-202', description:'Bias circuit aging indicator.' },
    { test_code:'TSETUP', test_name:'Setup Time Margin', category:'TIMING', unit:'ps', typical_value:180.0, abs_max_limit:350.0, abs_min_limit:80.0, safety_slope_multiplier:0.003, standard:'JEDEC JESD22-A108', description:'Clock margin erosion indicator.' },
    { test_code:'THOLD', test_name:'Hold Time Margin', category:'TIMING', unit:'ps', typical_value:120.0, abs_max_limit:250.0, abs_min_limit:40.0, safety_slope_multiplier:0.003, standard:'JEDEC JESD22-A108', description:'Increases under NBTI degradation.' },
    { test_code:'TID', test_name:'Total Ionizing Dose', category:'RADIATION', unit:'krad(Si)', typical_value:0.5, abs_max_limit:3.0, abs_min_limit:0.0, safety_slope_multiplier:0.005, standard:'MIL-STD-1019 / ESCC 22900', description:'Flat-band voltage shift from radiation.' },
    { test_code:'SEL', test_name:'Single-Event Latchup Current', category:'RADIATION', unit:'mA', typical_value:0.2, abs_max_limit:2.0, abs_min_limit:0.0, safety_slope_multiplier:0.006, standard:'ECSS-Q-ST-60-15C', description:'Latchup current from heavy-ion exposure.' },
    { test_code:'ESD_HBM', test_name:'ESD HBM Threshold', category:'MECHANICAL', unit:'V', typical_value:2000.0, abs_max_limit:4000.0, abs_min_limit:1000.0, safety_slope_multiplier:-0.002, standard:'AEC-Q100-002 / MIL-STD-883K', description:'Human Body Model ESD robustness.' },
    { test_code:'TEMP_CYCLE', test_name:'Thermal Cycling Delta (ΔR)', category:'MECHANICAL', unit:'mΩ', typical_value:0.5, abs_max_limit:3.0, abs_min_limit:0.0, safety_slope_multiplier:0.01, standard:'MIL-STD-883K Method 1010', description:'Mechanical fatigue / solder joint indicator.' },
  ],

  summary: {
    total_components: 1440, total_passed: 1362, total_rejected: 78,
    total_latent_caught: 38, total_drift_flags: 24, overall_pass_rate: 94.6,
    parameters_tested: ['IDDQ','ILEAK','TPROP','VTH_N','VTH_P','ICC','VOUT','CMRR'],
    lot_summaries: [
      { lot_id:'LOT-A77', total:240, passed:224, rejected:16, pass_rate:93.3 },
      { lot_id:'LOT-B12', total:240, passed:229, rejected:11, pass_rate:95.4 },
      { lot_id:'LOT-C34', total:240, passed:228, rejected:12, pass_rate:95.0 },
      { lot_id:'LOT-D91', total:240, passed:231, rejected: 9, pass_rate:96.3 },
      { lot_id:'LOT-E55', total:240, passed:225, rejected:15, pass_rate:93.8 },
      { lot_id:'LOT-F03', total:240, passed:225, rejected:15, pass_rate:93.8 },
    ],
  },

  components: Array.from({ length: 50 }, (_, i) => {
    const lots = ['LOT-A77','LOT-B12','LOT-C34','LOT-D91'];
    const params = ['IDDQ','ILEAK','TPROP','VTH_N','VTH_P'];
    const lot = lots[i % lots.length];
    const param = params[i % params.length];
    const v0 = +(10 + (Math.random()-0.3)*8).toFixed(4);
    const v24 = +(v0 * (1 + (Math.random()-0.4)*0.15)).toFixed(4);
    const v96 = +(v24 * (1 + (Math.random()-0.4)*0.12)).toFixed(4);
    const v168 = +(v96 * (1 + (Math.random()-0.4)*0.10)).toFixed(4);
    const z = +((v0 - 10) / 1.5).toFixed(3);
    const isAnomaly = Math.abs(z) > 2.8;
    return {
      component_id: `${lot}-${param}-${String(i+1).padStart(5,'0')}`,
      lot_id: lot, parameter: param, unit: 'µA',
      value_0h: v0, value_24h: v24, value_96h: v96, value_168h: v168,
      lot_mean: 10.0, lot_sigma: 1.5, z_score: z,
      abs_limit_max: 50, module_a_flag: isAnomaly, module_b_flag: false,
      is_hard_fail: v0 > 45, is_latent_defect: isAnomaly && v0 < 45,
      anomaly_score: Math.min(100, Math.round(Math.abs(z) / 3 * 60)),
      drift_rate: +(((v168-v0)/168)*1000).toFixed(4),
      final_decision: isAnomaly ? 'REJECT' : 'PASS',
      confidence: +(0.7 + Math.random() * 0.25).toFixed(3),
    };
  }),
};
