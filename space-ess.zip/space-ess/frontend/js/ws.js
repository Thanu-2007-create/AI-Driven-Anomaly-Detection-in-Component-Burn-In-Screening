// ============================================================
//  ESS-AI FRONTEND — js/ws.js
//  WebSocket Live Screening Feed
// ============================================================

class LiveScreeningFeed {
  constructor(url = 'ws://localhost:8000/ws/live') {
    this.url = url;
    this.ws = null;
    this.handlers = [];
    this.reconnectDelay = 3000;
    this.isConnected = false;
    this.eventCount = 0;
    this._connect();
  }

  _connect() {
    try {
      this.ws = new WebSocket(this.url);

      this.ws.onopen = () => {
        this.isConnected = true;
        console.log('[ESS-AI WS] Live feed connected');
        document.querySelectorAll('.ws-status').forEach(el => {
          el.textContent = '🟢 LIVE FEED';
          el.style.color = 'var(--success)';
        });
        this._emit({ type: 'connection', status: 'connected' });
      };

      this.ws.onmessage = (evt) => {
        try {
          const data = JSON.parse(evt.data);
          this.eventCount++;
          this._emit(data);
        } catch (e) {
          console.error('[ESS-AI WS] Parse error', e);
        }
      };

      this.ws.onclose = () => {
        this.isConnected = false;
        document.querySelectorAll('.ws-status').forEach(el => {
          el.textContent = '🟡 SIMULATED';
          el.style.color = 'var(--warning)';
        });
        // Auto-reconnect
        setTimeout(() => this._connect(), this.reconnectDelay);
        // Fall back to simulated events
        this._startSimulation();
      };

      this.ws.onerror = () => {
        this.isConnected = false;
        this._startSimulation();
      };

    } catch (e) {
      this._startSimulation();
    }
  }

  _startSimulation() {
    if (this._simInterval) return;
    const lots = ['LOT-A77','LOT-B12','LOT-C34','LOT-D91','LOT-E55','LOT-F03'];
    const params = ['IDDQ','ILEAK','TPROP','VTH_N','VTH_P','ICC','VOUT','TID','SEL'];
    const decisions = [...Array(18).fill('PASS'), 'REJECT', 'MARGINAL'];

    let cnt = 0;
    this._simInterval = setInterval(() => {
      const lot = lots[Math.floor(Math.random() * lots.length)];
      const param = params[Math.floor(Math.random() * params.length)];
      const decision = decisions[Math.floor(Math.random() * decisions.length)];
      const z = decision === 'PASS' ? (Math.random()-0.5)*2 : 3.2 + Math.random()*2;
      cnt++;
      this._emit({
        type: 'screening_event',
        timestamp: new Date().toISOString(),
        component_id: `${lot}-${param}-SIM${cnt.toString().padStart(5,'0')}`,
        lot_id: lot,
        parameter: param,
        value_0h: +(10 + z * 1.5).toFixed(4),
        z_score: +z.toFixed(3),
        decision,
        anomaly_score: Math.min(100, Math.round(Math.abs(z) / 3 * 60)),
        module: decision !== 'PASS' ? (Math.random() > 0.5 ? 'A' : 'B') : '—',
      });
    }, 1500 + Math.random() * 1000);
  }

  on(handler) {
    this.handlers.push(handler);
  }

  _emit(data) {
    this.handlers.forEach(h => {
      try { h(data); } catch(e) {}
    });
  }

  disconnect() {
    if (this.ws) this.ws.close();
    if (this._simInterval) clearInterval(this._simInterval);
  }
}

// Create global feed — pages can opt-in
window.liveFeed = null;
function startLiveFeed() {
  if (!window.liveFeed) {
    window.liveFeed = new LiveScreeningFeed();
  }
  return window.liveFeed;
}
